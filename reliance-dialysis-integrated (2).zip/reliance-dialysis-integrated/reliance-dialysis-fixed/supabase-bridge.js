/* Supabase adapter for the existing Reliance interface.
   The original HTML/CSS and page flow are retained; this file replaces demo-only
   authentication and core in-memory writes with Supabase Auth, PostgreSQL and Storage. */
(() => {
  const cfgUrl = window.RDC_SUPABASE_URL || '';
  const cfgKey = window.RDC_SUPABASE_ANON_KEY || '';
  const configured = cfgUrl.startsWith('https://') && cfgKey && !cfgKey.includes('YOUR_');
  let sb = null, booting = false, authListener = null;
  const fail = (err, fallback='The operation could not be completed.') => {
    console.error('[Reliance]', err);
    toast(err?.message || fallback);
  };
  const unwrap = ({data,error}) => { if(error) throw error; return data; };
  const isoDate = d => d ? String(d).slice(0,10) : '';
  const clearDemoState = () => {
    patients.splice(0); users.splice(0); A.splice(0); audit.splice(0);
    N.splice(0); ANN.splice(0); W.splice(0); sel=null; aid=1;
  };
  const byId = (arr,id) => arr.find(x => String(x.id)===String(id));
  const previewFns = {reg,lg,login,forgot,fg,reqA,appr,setS,cancelA,procRq,med,profSave,medSave,sv,saveInfo,addLab,saveTx,tgl,mkStaff,usersV,setSave,addDoc,annPost,nt};
  const logDb = async (message,details={}) => {
    if(!sb || !me?.id) return;
    const {error}=await sb.rpc('write_audit',{p_activity:message,p_details:details});
    if(error) console.warn('Audit write failed:',error.message);
  };
  window.rdcWriteAudit = logDb;
  window.rdcHoliday = async (op,d,n) => {
    if(!sb||!me?.id) return null;
    if(op==='add'){const {error}=await sb.from('holidays').insert({holiday_date:d,name:n}); if(error) throw error;}
    else {const {error}=await sb.from('holidays').delete().eq('holiday_date',d); if(error) throw error;}
    return true;
  };
  // Attach optional documents chosen during booking. Returns how many requirements were attached.
  window.rdcUploadDocs = async (list) => {
    if(!sb||!me?.pid) return null; const p=byId(patients,me.pid); if(!p) return 0;
    const {data:mr}=await sb.from('medical_records').select('document_manifest').eq('patient_id',me.pid).maybeSingle();
    if(!mr) return 0; // no medical record yet: upload under Medical Records after completing the profile
    const manifest=[...(mr.document_manifest||[])]; let n=0;
    for(const item of list){let ok=false;for(const file of item.files){
      if(!['application/pdf','image/jpeg','image/png'].includes(file.type)||file.size>5*1024*1024) continue;
      const path=`${me.pid}/${crypto.randomUUID()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;
      const {error}=await sb.storage.from('medical-documents').upload(path,file,{contentType:file.type}); if(error) continue;
      manifest.push({document_type:item.k,file_name:file.name,path,status:'pending_staff_approval',validation_result:'passed',submitted_at:new Date().toISOString(),size:file.size,mime_type:file.type}); ok=true;}
      if(ok) n++;}
    if(n){await sb.from('medical_records').update({document_manifest:manifest}).eq('patient_id',me.pid); await sb.from('patients').update({verification_status:'pending'}).eq('patient_id',me.pid); note('staff',`${p.name} attached ${n} document${n>1?'s':''} with a booking request.`);}
    return n;
  };
  window.rdcMarkRead = () => { if(sb&&me?.id) sb.rpc('mark_notifications_read').then(({error})=>{if(error)console.warn(error.message)}); };
  window.rdcWriteNotification = async (to,message) => {
    if(!sb||!me?.id)return;
    if(to==='staff'||to==='admin') {const {error}=await sb.rpc('create_notification',{p_target_user_id:null,p_target_role:to,p_message:message});if(error)throw error;return;}
    if(String(to).startsWith('p')) {const patient=byId(patients,String(to).slice(1));if(!patient?.user_id)return;const {error}=await sb.rpc('create_notification',{p_target_user_id:patient.user_id,p_target_role:null,p_message:message});if(error)throw error;}
  };
  const getUserRow = async uid => unwrap(await sb.from('users').select('*').eq('user_id',uid).single());
  const signedDocList = async manifest => Promise.all((manifest||[]).map(async d => {
    if(!d.path) return {...d,url:'#'};
    const {data,error}=await sb.storage.from('medical-documents').createSignedUrl(d.path,3600);
    return {...d,k:d.document_type||d.k,name:d.file_name||d.name,url:error?'#':data.signedUrl};
  }));
  window.rdcGetPatientDocuments = async patientId => {
    if(!sb)return byId(patients,patientId)?.docs||[];
    if(!me||!['staff','admin'].includes(me.role))throw new Error('Only staff can view patient documents.');
    const {data,error}=await sb.from('medical_records').select('document_manifest').eq('patient_id',patientId).maybeSingle();
    if(error)throw error;
    return Promise.all((data?.document_manifest||[]).map(async d=>{
      if(!d.path)return {...d,k:d.document_type||d.k,name:d.file_name||d.name,url:'#'};
      const {data:file,error:fileError}=await sb.storage.from('medical-documents').createSignedUrl(d.path,3600);
      if(fileError)throw fileError;
      return {...d,k:d.document_type||d.k,name:d.file_name||d.name,url:file.signedUrl};
    }));
  };

  async function loadData(userRow) {
    clearDemoState();
    const role=userRow.role;
    const [uRes,pRes,mRes,aRes,slRes,scRes,macRes,sesRes,auRes,nRes,annRes]=await Promise.all([
      sb.from('users').select('user_id,name,email,role,is_active,created_at'),
      sb.from('patients').select('*'),
      sb.from('medical_records').select('*'),
      sb.from('appointments').select('*'),
      sb.from('appointment_slots').select('*'),
      sb.from('schedules').select('*'),
      sb.from('dialysis_machines').select('*').order('machine_number'),
      sb.from('dialysis_sessions').select('*'),
      role==='admin'?sb.from('audit_logs').select('*').order('created_at',{ascending:false}).limit(200):Promise.resolve({data:[],error:null}),
      sb.from('notifications').select('*').order('created_at',{ascending:false}).limit(200),
      sb.from('announcements').select('*').order('created_at',{ascending:false}).limit(100)
    ]);
    for(const r of [uRes,pRes,mRes,aRes,slRes,scRes,macRes,sesRes,auRes,nRes,annRes]) if(r.error) throw r.error;
    const userRows=uRes.data||[], patientRows=pRes.data||[], medRows=mRes.data||[], slotRows=slRes.data||[], scheduleRows=scRes.data||[], machineRows=macRes.data||[], sessionRows=sesRes.data||[];
    const userMap=new Map(userRows.map(u=>[u.user_id,u]));
    const medMap=new Map(medRows.map(m=>[m.patient_id,m]));
    const machineMap=new Map(machineRows.map(m=>[m.machine_id,m]));
    const slotMap=new Map(slotRows.map(s=>[s.slot_id,s]));
    const scheduleMap=new Map(scheduleRows.map(s=>[s.schedule_id,s]));
    CAP=1;
    OPEN=[0,1,1,1,1,1,1];
    scheduleRows.forEach(s=>{if(s.shift_number===1 && s.status==='inactive') OPEN[s.operating_day]=0;});
    for(const row of patientRows){
      const u=userMap.get(row.user_id)||{}; const m=medMap.get(row.patient_id)||{};
      const docs=await signedDocList(m.document_manifest||[]);
      patients.push({id:row.patient_id,user_id:row.user_id,name:u.name||'Patient',email:u.email||'',gender:row.gender||'',dob:isoDate(row.date_of_birth),cs:row.civil_status||'',adr:row.address||'',contact:row.contact_number||'',em:[row.emergency_contact_name,row.emergency_contact_number].filter(Boolean).join(', '),phn:row.philhealth_number||'',joined:isoDate(row.created_at),notes:m.administrative_notes||'',ver:row.verification_status||'not_submitted',docs,labs:m.laboratory_results||[],med:m.record_id?{bt:m.blood_type||'',dx:m.kidney_condition||'',rp:m.attending_nephrologist||'',ds:isoDate(m.dialysis_start_date),va:m.dialysis_access||'',pf:m.preferred_schedule||'',al:m.allergies||'',md:m.current_medications||'',cm:m.other_conditions||'',lab:isoDate(m.latest_lab_date)}:null});
    }
    users.push(...userRows.map(u=>({id:u.user_id,email:u.email,name:u.name,role:u.role,off:!u.is_active,pid:(patientRows.find(p=>p.user_id===u.user_id)||{}).patient_id})));
    for(const row of aRes.data||[]){
      const slot=slotMap.get(row.slot_id)||{}, schedule=scheduleMap.get(slot.schedule_id)||{}, machine=machineMap.get(slot.machine_id)||{};
      const session=sessionRows.find(x=>x.appointment_id===row.appointment_id);
      A.push({id:row.appointment_id,pid:row.patient_id,slotId:row.slot_id,date:isoDate(slot.appointment_date),shift:(schedule.shift_number||1)-1,machine:machine.machine_number||null,status:row.appointment_status,rq:row.change_request_status==='pending'?{type:row.change_request_type,date:isoDate(row.requested_date),shift:(row.requested_shift||1)-1}:null,tx:session?.treatment_details||null,sessionId:session?.session_id||null});
    }
    audit.push(...(auRes.data||[]).map(x=>({t:x.created_at?new Date(x.created_at).toLocaleString('en-PH'):'',u:userMap.get(x.staff_id)?.name||'User',m:x.activity})));
    {const hr=await sb.from('holidays').select('*'); if(!hr.error&&hr.data&&hr.data.length){HOL.length=0; HOL.push(...hr.data.map(h=>({d:h.holiday_date,n:h.name})));}}
    N.push(...(nRes.data||[]).map(n=>({id:n.notification_id,to:n.recipient_user_id?'p'+(patientRows.find(p=>p.user_id===n.recipient_user_id)?.patient_id||''):n.recipient_role,m:n.message,t:new Date(n.created_at).toLocaleString('en-PH'),read:n.is_read?1:0})));
    ANN.push(...(annRes.data||[]).map(a=>({id:a.announcement_id,title:a.title,msg:a.message,img:a.image_path?sb.storage.from('announcements').getPublicUrl(a.image_path).data.publicUrl:'',t:new Date(a.created_at).toLocaleString('en-PH')})));
    me={id:userRow.user_id,email:userRow.email,role:userRow.role,name:userRow.name,pid:(patientRows.find(p=>p.user_id===userRow.user_id)||{}).patient_id};
    if(me.role==='patient'&&!me.pid) throw new Error('Your patient profile has not been created. Contact the administrator.');
    tab={patient:'pdash',staff:'sdash',admin:'dash'}[me.role]||'home';
  }

  async function refresh() {
    const {data:{user},error}=await sb.auth.getUser();
    if(error) throw error;
    if(!user){me=null;clearDemoState();const {data:publicAnnouncements}=await sb.from('announcements').select('*').order('created_at',{ascending:false}).limit(100);ANN.push(...(publicAnnouncements||[]).map(a=>({id:a.announcement_id,title:a.title,msg:a.message,img:a.image_path?sb.storage.from('announcements').getPublicUrl(a.image_path).data.publicUrl:'',t:new Date(a.created_at).toLocaleString('en-PH')})));render();return;}
    const profile=await getUserRow(user.id);
    if(!profile.is_active){await sb.auth.signOut();me=null;render();toast('This account is deactivated. Contact the administrator.');return;}
    await loadData(profile); render();
  }

  // Replace demo authentication. Supabase Auth stores password hashes and session tokens.
  reg = async function(e){
    e.preventDefault();
    const v=id=>$('#'+id).value, email=v('e').trim().toLowerCase();
    try {
      const {data,error}=await sb.auth.signUp({email,password:v('p'),options:{data:{name:v('n'),account_type:'patient',gender:v('g'),date_of_birth:v('b'),civil_status:v('cs'),address:v('ad'),contact_number:v('c'),emergency_contact_name:v('en'),emergency_contact_number:v('ec')}}});
      if(error) throw error;
      if(!data.session){toast('Account created. Check your email to confirm it, then log in.');go('login');return;}
      const {error:pe}=await sb.from('patients').update({gender:v('g'),date_of_birth:v('b'),civil_status:v('cs'),address:v('ad'),contact_number:v('c'),emergency_contact_name:v('en'),emergency_contact_number:v('ec')}).eq('user_id',data.user.id);
      if(pe) throw pe;
      await refresh(); log('Registered patient account');
      toast('Account created. Complete your medical record to continue.');
    } catch(err){fail(err,'Registration failed.');}
  };
  lg = async function(e){
    e.preventDefault();
    try {
      const {data,error}=await sb.auth.signInWithPassword({email:$('#le').value.trim().toLowerCase(),password:$('#lp').value});
      if(error) throw error;
      const profile=await getUserRow(data.user.id);
      if(!profile.is_active){await sb.auth.signOut();throw new Error('This account is deactivated. Contact the administrator.');}
      await loadData(profile); log('Logged in'); render();
    } catch(err){fail(err,'Email or password is incorrect.');}
  };
  window.rdcLogout=async()=>{if(sb){try{await sb.auth.signOut();}catch(e){console.error(e);}clearDemoState();}me=null;go('home');};
  login=()=>lg2();

  // Appointment requests are created by a PostgreSQL RPC to prevent overbooking.
  reqA = async function(date,shift){
    try {
      if(rs){
        const old=byId(A,rs); if(!old) throw new Error('Appointment not found.');
        if(old.status==='pending'){
          const {error}=await sb.rpc('reschedule_pending_appointment',{p_appointment_id:old.id,p_new_date:date,p_new_shift:shift+1}); if(error) throw error;
        } else {
          const {error}=await sb.rpc('request_appointment_change',{p_appointment_id:old.id,p_change_type:'reschedule',p_new_date:date,p_new_shift:shift+1}); if(error) throw error;
        }
        rs=null;
      } else {
        const {error}=await sb.rpc('request_appointment',{p_date:date,p_shift_number:shift+1}); if(error) throw error;
      }
      cd=null; note('staff',`${me.name} requested ${fmt(date)}, ${SH[shift].split(' ')[0]}.`); await refresh(); await logDb('Submitted appointment request',{date,shift:shift+1}); toast('Appointment request sent. Status: pending.');
    } catch(err){fail(err,'Unable to request this appointment.');}
  };
  appr = async function(id){
    try {const a=byId(A,id),v=$('#mc'+id)?.value||'auto',machine=v==='auto'?null:Number(v);const {error}=await sb.rpc('approve_appointment',{p_appointment_id:id,p_machine_number:machine});if(error)throw error;if(a)note('p'+a.pid,`Approved: your appointment on ${fmt(a.date)}, ${SH[a.shift].split(' ')[0]}.`);await refresh();await logDb('Approved appointment',{appointment_id:id,machine_number:machine});toast('Appointment confirmed.');}
    catch(err){fail(err,'Unable to approve appointment.');}
  };
  setS = async function(id,status,machineNumber){
    try {
      const a=byId(A,id); if(!a) throw new Error('Appointment not found.');
      if(['completed','missed'].includes(status)&&a.date>TODAY) throw new Error('A session can only be marked after its date.');
      if(status==='confirmed'){
        const {error}=await sb.rpc('approve_appointment',{p_appointment_id:id,p_machine_number:machineNumber||null});if(error)throw error;
      } else {
        const {error}=await sb.from('appointments').update({appointment_status:status,updated_at:new Date().toISOString()}).eq('appointment_id',id);if(error)throw error;
        if(['completed','missed','cancelled'].includes(status)){
          const {data:slot,error:se}=await sb.from('appointment_slots').select('appointment_date,machine_id').eq('slot_id',a.slotId).single();if(se)throw se;
          const {error:ue}=await sb.from('dialysis_sessions').upsert({appointment_id:id,machine_id:slot.machine_id,staff_id:me.id,session_date:slot.appointment_date,session_status:status,treatment_details:a.tx||{}},{onConflict:'appointment_id'});if(ue)throw ue;
        }
      }
      if(me.role==='staff'||me.role==='admin'){const msg=status==='declined'?`Your request for ${fmt(a.date)}, ${SH[a.shift].split(' ')[0]} was rejected. Please choose another schedule.`:status==='completed'?`Your dialysis session on ${fmt(a.date)} was marked completed.`:status==='missed'?`Your dialysis session on ${fmt(a.date)} was marked missed.`:status==='cancelled'?`Your appointment on ${fmt(a.date)} was cancelled.`:'';if(msg)note('p'+a.pid,msg);}await refresh(); await logDb('Updated appointment status',{appointment_id:id,status}); toast('Appointment '+status+'.');
    } catch(err){fail(err,'Unable to update appointment.');}
  };
  cancelA = async function(id){
    try {const a=byId(A,id);if(!a)throw new Error('Appointment not found.');
      if(a.status==='pending'){const {error}=await sb.rpc('cancel_pending_appointment',{p_appointment_id:id});if(error)throw error;}
      else {const {error}=await sb.rpc('request_appointment_change',{p_appointment_id:id,p_change_type:'cancel',p_new_date:null,p_new_shift:null});if(error)throw error;}
      note('staff',`${me.name} requested cancellation of ${fmt(a.date)}, ${SH[a.shift].split(' ')[0]}.`);await refresh();await logDb('Requested appointment cancellation',{appointment_id:id});toast('Cancellation request sent.');
    }catch(err){fail(err,'Unable to request cancellation.');}
  };
  procRq = async function(id,approve){
    try {const a=byId(A,id),rq=a?.rq;const {error}=await sb.rpc('process_appointment_change_request',{p_appointment_id:id,p_approve:!!approve});if(error)throw error;if(a)note('p'+a.pid,approve?(rq?.type==='cancel'?'Your cancellation request was approved.':`Your appointment reschedule request was approved.`):(rq?.type==='cancel'?'Your cancellation request was rejected. Your appointment remains scheduled.':'Your reschedule request was rejected. Your appointment remains scheduled.'));await refresh();await logDb(approve?'Approved appointment change request':'Rejected appointment change request',{appointment_id:id});toast(approve?'Request approved.':'Request rejected.');}
    catch(err){fail(err,'Unable to process the change request.');}
  };

  // Medical information and uploaded files are saved in PostgreSQL and private Storage.
  async function collectAndUploadDocuments(patientId){
    const entries=[]; const missing=[]; let problem=''; const patientNow=byId(patients,me.pid); const acceptedDocs=(patientNow?.docs||[]).filter(d=>['approved','pending_staff_approval'].includes(d.status));
    for(const group of DOCS){
      for(const doc of group[2]){
        const input=$('#f_'+doc[0]); const files=Array.from(input?.files||[]);
        const required=group[0]==='med' && !!doc[2];
        const existingCount=acceptedDocs.filter(d=>d.key===doc[0] || d.k===doc[1].split(':')[0].split(' (')[0] || d.document_type===doc[1].split(':')[0].split(' (')[0]).length;
        if(required && !files.length && existingCount===0){problem ||= `${doc[1]} is required.`;missing.push({document_type:doc[1].split(':')[0].split(' (')[0],key:doc[0],status:'automatically_rejected',validation_result:'failed',reason:'Required document was not uploaded.',submitted_at:new Date().toISOString()});}
        if(doc[0]==='trt' && files.length+existingCount!==3){problem ||= 'Please upload exactly three treatment sheets in total.';if(files.length+existingCount!==3)missing.push({document_type:'Last 3 treatment sheets',key:'trt',status:'automatically_rejected',validation_result:'failed',reason:'Exactly three treatment sheets are required.',submitted_at:new Date().toISOString()});}
        for(const file of files){
          const validType=['application/pdf','image/jpeg','image/png'].includes(file.type);
          if(!validType) problem ||= `${file.name}: only PDF, JPG, and PNG files are accepted.`;
          if(file.size>5*1024*1024) problem ||= `${file.name}: file exceeds the 5 MB limit.`;
          entries.push({key:doc[0],label:doc[1].split(':')[0].split(' (')[0],file});
        }
      }
    }
    const labDate=$('#lb')?.value||'';
    if(!labDate) problem ||= 'Enter the date of the latest laboratory results.';
    else {const age=(new Date(TODAY+'T12:00:00')-new Date(labDate+'T12:00:00'))/86400000;if(age<0||age>7)problem ||= 'CBC and chest X-ray results must be dated within the last 7 days.';}
    if(problem) return {error:problem,manifest:[...missing,...entries.map(x=>({document_type:x.label,key:x.key,file_name:x.file.name,status:'automatically_rejected',validation_result:'failed',reason:problem,submitted_at:new Date().toISOString()}))]};
    const manifest=[];
    for(const item of entries){
      const safe=item.file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
      const path=`${patientId}/${crypto.randomUUID()}_${safe}`;
      const {error}=await sb.storage.from('medical-documents').upload(path,item.file,{contentType:item.file.type,upsert:false});
      if(error) throw error;
      manifest.push({document_type:item.label,key:item.key,file_name:item.file.name,path,status:'pending_staff_approval',validation_result:'passed',submitted_at:new Date().toISOString(),size:item.file.size,mime_type:item.file.type});
    }
    // Optional PhilHealth documents are also accepted and validated if supplied.
    return {manifest};
  }
  profSave = async function(e){
    e.preventDefault();
    try{
      const p=byId(patients,me.pid);if(!p)throw new Error('Patient profile not found.');
      const v=id=>$('#'+id)?.value||'';
      const docs=await collectAndUploadDocuments(me.pid);
      const patientPatch={gender:v('g'),date_of_birth:v('b')||null,civil_status:v('cs'),address:v('ad'),contact_number:v('c'),emergency_contact_name:v('en'),emergency_contact_number:v('ec'),philhealth_number:v('pn')||null,verification_status:docs.error?'incomplete':'pending'};
      const {error:pe}=await sb.from('patients').update(patientPatch).eq('patient_id',me.pid);if(pe)throw pe;
      const medicalPatch={patient_id:me.pid,blood_type:v('bt'),kidney_condition:typeof pickDx==='function'?pickDx():v('dx'),attending_nephrologist:v('rp'),dialysis_start_date:v('ds')||null,dialysis_access:v('va'),preferred_schedule:v('pf'),allergies:typeof pickAl==='function'?pickAl():v('al'),current_medications:v('md'),other_conditions:[...document.querySelectorAll('.cm:checked')].map(x=>x.value).join(', '),latest_lab_date:v('lb')||null};
      const old=(p.docs||[]).filter(d=>d.path).map(d=>({document_type:d.k,file_name:d.name,path:d.path,status:d.status||'pending_staff_approval'}));
      medicalPatch.document_manifest=docs.error?[...old,...docs.manifest]:[...old,...docs.manifest];
      const {error:meErr}=await sb.from('medical_records').upsert(medicalPatch,{onConflict:'patient_id'});if(meErr)throw meErr;
      await refresh();
      if(docs.error){toast('Automatically rejected: '+docs.error+' Correct the requirements and submit again.');tab='med';render();return;}
      note('staff',`${me.name} completed their profile and submitted medical requirements for staff review.`);await logDb('Completed patient profile and submitted medical requirements');tab='pdash';render();toast('Profile submitted. Documents passed automatic checks and are pending staff approval.');
    }catch(err){fail(err,'Unable to submit patient profile.');}
  };

  medSave = async function(e){
    e.preventDefault();
    try {
      const p=byId(patients,me.pid); if(!p)throw new Error('Patient profile not found.');
      const v=id=>$('#'+id)?.value||'';
      const docs=await collectAndUploadDocuments(me.pid);
      if(docs.error){
        await sb.from('patients').update({verification_status:'incomplete'}).eq('patient_id',me.pid);
        const old=(p.docs||[]).map(d=>({document_type:d.k,file_name:d.name,path:d.path,status:d.status||'pending_staff_approval'}));
        await sb.from('medical_records').upsert({patient_id:me.pid,blood_type:v('bt'),kidney_condition:v('dx'),attending_nephrologist:v('rp'),dialysis_start_date:v('ds')||null,dialysis_access:v('va'),preferred_schedule:v('pf'),allergies:v('al'),current_medications:v('md'),other_conditions:[...document.querySelectorAll('.cm:checked')].map(x=>x.value).join(', '),latest_lab_date:v('lb')||null,document_manifest:[...old,...docs.manifest]},{onConflict:'patient_id'});
        await refresh(); toast('Automatically rejected: '+docs.error+' Correct the requirements and submit again.'); return;
      }
      const {error}=await sb.from('medical_records').upsert({patient_id:me.pid,blood_type:v('bt'),kidney_condition:v('dx'),attending_nephrologist:v('rp'),dialysis_start_date:v('ds')||null,dialysis_access:v('va'),preferred_schedule:v('pf'),allergies:v('al'),current_medications:v('md'),other_conditions:[...document.querySelectorAll('.cm:checked')].map(x=>x.value).join(', '),latest_lab_date:v('lb')||null,document_manifest:[...(p.docs||[]).filter(d=>d.path).map(d=>({document_type:d.k,file_name:d.name,path:d.path,status:d.status||'pending_staff_approval'})),...docs.manifest]},{onConflict:'patient_id'});if(error)throw error;
      const {error:pe}=await sb.from('patients').update({philhealth_number:v('pn')||null,verification_status:'pending'}).eq('patient_id',me.pid);if(pe)throw pe;
      await refresh();tab='book';render();await logDb('Submitted medical record and documents');toast('Documents passed automatic checks and were sent for staff approval.');
    }catch(err){fail(err,'Unable to save medical record.');}
  };
  sv = async function(e){e.preventDefault();try{const p=byId(patients,sel);const {error}=await sb.from('patients').update({contact_number:$('#rc').value,date_of_birth:$('#rb')?.value||p.dob,verification_status:$('#rv')?.value||p.ver}).eq('patient_id',sel);if(error)throw error;const {data:mr,error:mrErr}=await sb.from('medical_records').select('document_manifest').eq('patient_id',sel).maybeSingle();if(mrErr)throw mrErr;if(mr){const selectedStatus=$('#rv')?.value||'pending';const nextStatus=selectedStatus==='verified'?'approved':selectedStatus==='incomplete'?'staff_rejected':'pending_staff_approval';const manifest=(mr.document_manifest||[]).map(d=>d.status==='pending_staff_approval'?{...d,status:nextStatus,reviewed_at:new Date().toISOString(),reviewed_by:me.id}:d);const {error:docErr}=await sb.from('medical_records').update({document_manifest:manifest,administrative_notes:$('#rn').value}).eq('patient_id',sel);if(docErr)throw docErr;}note('p'+p.id,'Your patient record was reviewed or updated by staff. Check Medical Records for the latest status.');await refresh();sel=p.id;render();await logDb('Updated patient record',{patient_id:sel});toast('Record saved.');}catch(err){fail(err,'Unable to save patient record.');}};
  saveInfo = async function(e){e.preventDefault();try{const v=id=>$('#ei'+id).value;const p=byId(patients,sel);const {error}=await sb.from('patients').update({gender:v(2),date_of_birth:v(3)||null,address:v(4),emergency_contact_name:v(5)}).eq('patient_id',sel);if(error)throw error;const {error:userErr}=await sb.from('users').update({name:v(1)}).eq('user_id',p.user_id);if(userErr)throw userErr;const {error:meErr}=await sb.from('medical_records').upsert({patient_id:sel,blood_type:v(6),kidney_condition:v(7),attending_nephrologist:v(8),dialysis_access:v(9),allergies:v(10),current_medications:v(11)},{onConflict:'patient_id'});if(meErr)throw meErr;await refresh();sel=p.id;render();await logDb('Edited patient information',{patient_id:sel});toast('Information saved.');}catch(err){fail(err,'Unable to update patient information.');}};
  addLab = async function(e){e.preventDefault();try{const p=byId(patients,sel),labs=[{t:$('#lt').value,v:$('#lv').value,d:$('#ld').value},...(p.labs||[])];const {error}=await sb.from('medical_records').update({laboratory_results:labs,latest_lab_date:$('#ld').value}).eq('patient_id',sel);if(error)throw error;note('p'+p.id,'A new laboratory result is available in your Medical Records.');await refresh();sel=p.id;render();await logDb('Released laboratory result',{patient_id:sel});toast('Result released to patient.');}catch(err){fail(err,'Unable to save laboratory result.');}};
  saveTx = async function(e){e.preventDefault();try{const a=byId(A,+$('#tx0').value)||byId(A,$('#tx0').value),p=byId(patients,sel);const v=id=>$('#tx'+id).value;const details={weight_before:v(1),weight_after:v(2),blood_pressure:v(3),duration_hours:v(4),notes:v(5)};const {data:slot,error:se}=await sb.from('appointment_slots').select('appointment_date,machine_id').eq('slot_id',a.slotId).single();if(se)throw se;const {error}=await sb.from('dialysis_sessions').upsert({appointment_id:a.id,machine_id:slot.machine_id,staff_id:me.id,session_date:slot.appointment_date,session_status:'completed',treatment_details:details},{onConflict:'appointment_id'});if(error)throw error;note('p'+p.id,`Treatment details for ${fmt(a.date)} were added to your Medical Records.`);await refresh();sel=p.id;render();await logDb('Recorded treatment details',{patient_id:sel,appointment_id:a.id});toast('Treatment record saved.');}catch(err){fail(err,'Unable to save treatment record.');}};

  const originalMedicalPage=med;
  med = function(S){
    const p=byId(patients,me?.pid);
    if(p?.ver==='incomplete'){
      prof(S);
      const m=p.med||{}, parts=(p.em||'').split(',');
      const values={g:p.gender,b:p.dob,cs:p.cs,ad:p.adr,c:p.contact,en:parts[0]||'',ec:parts.slice(1).join(',').trim(),bt:m.bt,dx:m.dx,rp:m.rp,ds:m.ds,va:m.va,pf:m.pf,al:m.al,md:m.md,pn:p.phn,lb:m.lab};
      Object.entries(values).forEach(([id,val])=>{const el=$('#'+id);if(el&&val!=null)el.value=val;});
      if(m.dx===DXO[DXO.length-1]){$('#dxx').value=m.dx;}
      if(m.al&&m.al!=='None'&&$('#alx')){$('#alx').value=m.al.includes(':')?m.al.split(':').slice(1).join(':').trim():m.al;}
      if(typeof spec==='function')spec();
      const heading=S.querySelector('h2');if(heading)heading.textContent='Correct and resubmit your profile';
      const msg=S.querySelector('.mut');if(msg)msg.textContent='Some submitted requirements were automatically rejected or marked incomplete. Correct the required information and upload the missing or corrected documents.';
      return;
    }
    originalMedicalPage(S);
  };

  addDoc = async function(e){
    e.preventDefault();
    try{const p=byId(patients,me.pid),file=$('#nd').files[0],kind=$('#ndt').value;if(!file)throw new Error('Choose a document first.');
      if(!['application/pdf','image/jpeg','image/png'].includes(file.type))throw new Error('Only PDF, JPG, and PNG files are accepted.');
      if(file.size>5*1024*1024)throw new Error('File exceeds the 5 MB limit.');
      const path=`${me.pid}/${crypto.randomUUID()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;
      const {error:upErr}=await sb.storage.from('medical-documents').upload(path,file,{contentType:file.type});if(upErr)throw upErr;
      const manifest=[...(p.docs||[]).filter(d=>d.path).map(d=>({document_type:d.k,file_name:d.name,path:d.path,status:d.status||'pending_staff_approval'})),{document_type:kind,file_name:file.name,path,status:'pending_staff_approval',validation_result:'passed',submitted_at:new Date().toISOString(),size:file.size,mime_type:file.type}];
      const {error}=await sb.from('medical_records').update({document_manifest:manifest}).eq('patient_id',me.pid);if(error)throw error;
      const {error:pe}=await sb.from('patients').update({verification_status:'pending'}).eq('patient_id',me.pid);if(pe)throw pe;
      note('staff',`${p.name} uploaded a document: ${kind}.`);await refresh();await logDb('Uploaded patient document',{document_type:kind});toast('Document passed automatic checks and is pending staff approval.');go(view);
    }catch(err){fail(err,'Unable to upload document.');}
  };
  forgot = () => window.RDC_RECOVERY ? `<form class="card" style="max-width:420px;margin:auto" onsubmit="fg(event)"><h2>Choose a new password</h2><label for="fp">New password</label><input id="fp" type="password" minlength="8" required><label for="fp2">Confirm new password</label><input id="fp2" type="password" minlength="8" required><br><button class="btn" style="width:100%">Update password</button></form>` : `<form class="card" style="max-width:420px;margin:auto" onsubmit="fg(event)"><h2>Reset password</h2><p class="mut">Enter your email address. If the account exists, we will send a password reset link.</p><label for="fe">Email</label><input id="fe" type="email" required><br><button class="btn" style="width:100%">Send reset link</button></form>`;
  fg = async function(e){e.preventDefault();try{if(!sb)throw new Error('Password recovery is available after connecting Supabase.');if(window.RDC_RECOVERY){if($('#fp').value!==$('#fp2').value)throw new Error('Passwords do not match.');const {error}=await sb.auth.updateUser({password:$('#fp').value});if(error)throw error;window.RDC_RECOVERY=false;toast('Password updated. Log in with your new password.');await sb.auth.signOut();go('login');return;}const {error}=await sb.auth.resetPasswordForEmail($('#fe').value.trim().toLowerCase(),{redirectTo:location.origin+location.pathname});if(error)throw error;toast('If the account exists, a password reset link has been sent to the email address.');go('login');}catch(err){fail(err,'Unable to update password.');}};

  const originalNt=nt;
  nt = function(S){originalNt(S);sb.rpc('mark_notifications_read').then(({error})=>{if(error)console.warn(error.message);else N.forEach(n=>n.read=1);});};
  annPost = async function(e){
    e.preventDefault();try{const title=$('#at').value.trim(),message=$('#am').value.trim(),file=$('#ai').files[0];let imagePath=null;
      if(file){if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>2*1024*1024)throw new Error('Choose a PNG, JPG, or WebP image under 2 MB.');imagePath=`${crypto.randomUUID()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;const {error}=await sb.storage.from('announcements').upload(imagePath,file,{contentType:file.type});if(error)throw error;}
      const {data,error}=await sb.from('announcements').insert({title,message,image_path:imagePath,posted_by:me.id}).select().single();if(error)throw error;
      ANN.unshift({id:data.announcement_id,title,msg:message,img:imagePath?sb.storage.from('announcements').getPublicUrl(imagePath).data.publicUrl:'',t:new Date(data.created_at).toLocaleString('en-PH')});
      await window.rdcWriteNotification('staff','Announcement: '+title);for(const p of patients)await window.rdcWriteNotification('p'+p.id,'Announcement: '+title);
      await logDb('Posted announcement',{title});toast('Announcement posted.');annV($('#s'));
    }catch(err){fail(err,'Unable to post announcement.');}
  };

  // Admin-only account maintenance is enforced again by RLS / Edge Function.
  tgl = async function(i){try{const u=users[i];if(!u||u.id===me.id)throw new Error('You cannot deactivate your own account.');const nextOff=!u.off;const {error}=await sb.from('users').update({is_active:!nextOff}).eq('user_id',u.id);if(error)throw error;await refresh();await logDb(u.off?'Deactivated account':'Activated account',{user_id:u.id});toast('Account status updated.');}catch(err){fail(err,'Unable to change account status.');}};
  mkStaff = async function(e){e.preventDefault();try{const {data,error}=await sb.functions.invoke('admin-create-user',{body:{name:$('#sn').value,email:$('#se').value.trim().toLowerCase(),password:$('#sp').value}});if(error)throw error;await refresh();await logDb('Created staff account',{email:$('#se').value});toast('Staff account created.');usersV($('#s'));}catch(err){fail(err,'Unable to create staff account. Deploy the admin-create-user Edge Function first.');}};
  usersV = (function(original){return function(S){original(S);S.querySelectorAll('select[aria-label="Role"]').forEach((el,i)=>{el.onchange=null;el.addEventListener('change',async()=>{try{const u=users[i];if(!u||u.id===me.id)throw new Error('You cannot change your own role.');const {error}=await sb.from('users').update({role:el.value}).eq('user_id',u.id);if(error)throw error;await refresh();await logDb('Changed user role',{user_id:u.id,role:el.value});toast('Role updated.');usersV($('#s'));}catch(err){fail(err,'Unable to update role.');}});});};})(usersV);
  setSave = async function(e){e.preventDefault();try{const newCap=1;const open=DN.map((_,i)=>document.querySelector('.od[value="'+i+'"]')?.checked?1:0);for(let day=0;day<7;day++)for(let shift=1;shift<=3;shift++){const {error}=await sb.from('schedules').update({status:open[day]?'active':'inactive'}).eq('operating_day',day).eq('shift_number',shift);if(error)throw error;}const {error}=await sb.from('dialysis_machines').update({machine_status:'inactive'}).gt('machine_number',newCap);if(error)throw error;const {error:ae}=await sb.from('dialysis_machines').update({machine_status:'active'}).eq('machine_number',newCap);if(ae)throw ae;await refresh();await logDb('Updated schedule and machine settings',{machine_capacity:newCap,operating_days:open});toast('Settings saved.');setV($('#s'));}catch(err){fail(err,'Unable to update schedule and machine settings.');}};

  if(!configured){
    reg=previewFns.reg;lg=previewFns.lg;login=previewFns.login;forgot=previewFns.forgot;fg=previewFns.fg;
    reqA=previewFns.reqA;appr=previewFns.appr;setS=previewFns.setS;cancelA=previewFns.cancelA;procRq=previewFns.procRq;
    med=previewFns.med;profSave=previewFns.profSave;medSave=previewFns.medSave;sv=previewFns.sv;saveInfo=previewFns.saveInfo;
    addLab=previewFns.addLab;saveTx=previewFns.saveTx;tgl=previewFns.tgl;mkStaff=previewFns.mkStaff;usersV=previewFns.usersV;
    setSave=previewFns.setSave;addDoc=previewFns.addDoc;annPost=previewFns.annPost;nt=previewFns.nt;
  }

  // The legacy announcements/notifications/chat assistant remain in their original UI.
  // They are supplementary to the paper's core DFD/ERD and are not used for clinical decisions.
  window.RDC_SUPABASE_CONNECTED = configured;
  window.RDC_SUPABASE_CLIENT = null;

  async function start(){
    if(booting)return;booting=true;
    if(!configured){render();$('#v').insertAdjacentHTML('afterbegin','<div class="rec warn" style="margin:12px 0">Database is not connected yet. This is the original interface in preview mode. Add your Supabase Project URL and publishable key in <b>supabase-config.js</b> after creating your project.</div>');return;}
    if(!window.supabase?.createClient){render();toast('Supabase library did not load. Check your internet connection.');return;}
    sb=window.supabase.createClient(cfgUrl,cfgKey);window.RDC_SUPABASE_CLIENT=sb;
    try{await refresh();}catch(err){console.error(err);me=null;clearDemoState();render();toast('Database connection failed: '+(err.message||'Check your Supabase setup.'));}
    if(!authListener){const {data}=sb.auth.onAuthStateChange(async(_event,session)=>{if(_event==='PASSWORD_RECOVERY'){window.RDC_RECOVERY=true;view='forgot';render();return;}if(!session){me=null;clearDemoState();const {data:pa}=await sb.from('announcements').select('*').order('created_at',{ascending:false}).limit(100);ANN.push(...(pa||[]).map(a=>({id:a.announcement_id,title:a.title,msg:a.message,img:a.image_path?sb.storage.from('announcements').getPublicUrl(a.image_path).data.publicUrl:'',t:new Date(a.created_at).toLocaleString('en-PH')})));render();}else{try{const profile=await getUserRow(session.user.id);await loadData(profile);render();}catch(err){fail(err);}}});authListener=data.subscription;}
  }
  window.startRdc=start;
  start();
})();
