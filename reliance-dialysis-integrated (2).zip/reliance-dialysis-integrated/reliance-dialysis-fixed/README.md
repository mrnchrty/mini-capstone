# Reliance Dialysis Center Inc. — Supabase-connected source

This project keeps the supplied Reliance Dialysis Center interface and page flow. The original `app.js` and `styles.css` remain the UI base. The database adapter is added in `supabase-bridge.js`.

## Important

- The application is **not connected to a live database until you create a Supabase project and fill in `supabase-config.js`**.
- The app opens in preview mode while the config contains placeholders. Preview mode uses the original demo data held in memory; it is not persistent.
- After configuration, Supabase Auth, PostgreSQL, Row Level Security, and private Storage are used for the core patient, appointment, medical-record, session, account, notification, announcement, and audit workflows.
- Do not use real patient records until the center has reviewed the privacy, security, retention, and hosting configuration.
- Never put a Supabase `service_role` or secret key in `supabase-config.js` or any browser file.

## Run the interface locally

1. Extract the project folder.
2. Open a terminal in this folder.
3. Run `py -m http.server 5500` (or `python -m http.server 5500`).
4. Open `http://localhost:5500` in your browser.
5. Before configuring Supabase, use the preview-only accounts `patient@demo`, `returning@demo`, `staff@demo` or `admin@demo` (not shown on the page). Password for each is `demo`.

## Connect Supabase

Follow `SUPABASE_SETUP.md` in order. In short:

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Set the first administrator role using the SQL in `SUPABASE_SETUP.md`.
4. Copy the Project URL and publishable/anon key into `supabase-config.js`.
5. Deploy `supabase/functions/admin-create-user` so the administrator can create staff accounts.
6. Add `http://localhost:5500/**` to the Supabase Auth redirect allow list.
7. Reload the app and register/login with Supabase Auth.

## Core workflow in the connected version

1. Patient creates an account and completes the personal profile.
2. Patient submits the required medical documents. The browser checks required files, allowed file types, file size (5 MB maximum), three treatment sheets, and the latest lab date (within seven days).
3. Failed submissions are marked `automatically_rejected` / `incomplete` and are not eligible for appointment approval. Passed submissions are marked `pending_staff_approval` for staff review.
4. Staff verifies the submitted requirements and marks the patient verified or incomplete.
5. Verified patients can request an available date and shift. One active machine allows one appointment per shift (three per open day); a PostgreSQL function reserves the slot atomically to prevent overbooking.
6. Staff approves or rejects requests, assigns a machine, and updates session outcomes.
7. Staff maintains patient records and treatment details; patient records and admin reports can be printed to PDF using the browser's Print / Save as PDF function.
8. The administrator manages user roles, monitors audit activity, and views analytics generated from database records.

## Objectives and where they live

| Objective | Where |
|---|---|
| 1. Appointment calendar (patients pick date and time; staff manage and monitor) | Patient booking calendar: `book()` in `app.js`. Staff **Dashboard** (today's work at a glance) and the **Requests** tab, which provides a week schedule (`scal()` in `objectives.js`) showing patient names only; selecting an appointment opens the patient's full details and documents, with approve/reject actions in the popup for staff. Month and list views are also available. |
| 2. Centralized medical records | `rec()` in `app.js` (record, treatment, labs, documents). `objectives.js` adds search (name, email, contact, PhilHealth no.), filters (verification status, lab date) and sorting. |
| 3. Analytics dashboard | `dash()` in `objectives.js` (one consolidated function): monthly totals, cancelled and missed counts and %, highest and lowest month/weekday/shift, utilization by weekday/shift/machine, rule-based recommendations. |

Definitions: an *appointment* is a past booking that was not rejected or left pending. *Utilization* is completed plus missed sessions divided by machine-sessions available on operating days (holidays and closed days excluded). Recommendation thresholds are in the `RULES` object at the top of `objectives.js`.

## Database design notes

The core tables follow the supplied ERD: `users`, `patients`, `medical_records`, `schedules`, `appointment_slots`, `appointments`, `dialysis_sessions`, `dialysis_machines`, and `audit_logs`. The role is stored in `users.role`, as shown in the ERD; it is not a second authentication system. `document_manifest`, `laboratory_results`, and `treatment_details` are JSONB fields used to preserve the original document and treatment-record interface without creating unrelated clinical tables. `announcements` and `notifications` are small supporting tables for existing interface functions not represented as separate entities in the core ERD.

The analytics remain descriptive and rule-based. They do not diagnose patients, prescribe medication, determine dialysis treatment, or automatically change schedules.

## Files

- `index.html` — original main page structure.
- `styles.css` — original styling.
- `objectives.js` — staff calendar, record filters, consolidated analytics dashboard.
- `app.js` — original application interface and page workflow, with the database boot call moved to the bridge.
- `supabase-config.js` — Project URL and publishable/anon key placeholders.
- `supabase-bridge.js` — Supabase Auth, database, Storage, and persistence integration.
- `supabase/schema.sql` — PostgreSQL schema, RLS policies, functions, one active machine, and six-day/three-shift schedules.
- `supabase/functions/admin-create-user/index.ts` — secure Edge Function for administrator-created staff accounts.
- `dfd.html` — supplied DFD source file.

## Known implementation boundaries

- Automatic document checks are technical/predefined checks (file type, size, required document presence, treatment-sheet count, and lab-date recency). They do not establish the medical accuracy or authenticity of a document; staff still make the final verification.
- PDF output uses the browser print dialog. A server-side PDF rendering service is not included.
- The legacy waitlist and chatbot remain interface-side helpers; they are not core ERD data stores.
- The live Supabase connection cannot be exercised until the project URL/key are configured and the SQL is deployed.

## Homepage notes

- The hero photo is read from `staff.jpg` in this folder (drop the staff photograph in with that name). Until it exists, the built-in blue placeholder is shown.
- The footer's Facebook link is set by `FB_URL` near the end of `app.js`; replace it with the center's exact Facebook page URL.
- The location popup uses a keyless Google Maps embed (`MAP_URL` in `app.js`).
