/* Reliance Dialysis Center Inc. - project objectives
   1. Staff appointment calendar (patients already use the booking calendar in app.js)
   2. Patient record retrieval: search, filters, sorting
   3. Analytics dashboard: descriptive (3.1-3.3) and rule-based prescriptive (3.4)
   Loaded after app.js and before supabase-bridge.js. Works on the shared globals (A, patients, CAP, OPEN, HOL ...). */

/* ---------- Rule thresholds (edit here to tune the recommendations) ---------- */
const RULES={highUtil:80,lowUtil:60,missedPct:7,cancelPct:8,shiftGap:25,machineLow:.5,soonFull:90,soonDays:14,minGroup:20};

const pct1=(a,b)=>b?100*a/b:0,f0=x=>Math.round(x),f1=x=>x.toFixed(1);
const MON=k=>new Date(k+'-15').toLocaleString('en',{month:'short',year:'numeric'});
const shortSh=j=>SH[j].split(' ')[0];

/* =====================================================================
   OBJECTIVE 3 - Analytics (descriptive + prescriptive)
   Definitions used everywhere on the dashboard:
   - Appointment: a past booking that was not rejected and not left pending.
   - Utilization: (completed + missed sessions) / machine-sessions available on operating days.
     Cancelled sessions free the machine, so they do not count as used.
   ===================================================================== */
function anStats(){
  const past=A.filter(a=>a.date&&a.date<TODAY),
    cnt=past.filter(a=>a.status!=='declined'&&a.status!=='pending'),
    n=s=>cnt.filter(a=>a.status===s).length,
    unres=past.filter(a=>a.status==='pending'||a.status==='confirmed').length,
    first=cnt.reduce((m,a)=>!m||a.date<m?a.date:m,''),
    occ=a=>a.status==='completed'||a.status==='missed',
    days=[];
  if(first)for(let d=pd(first);iso(d)<TODAY;d=addD(d,1)){const k=iso(d);if(OPEN[d.getDay()]&&!holName(k))days.push(k)}
  const blank=()=>({t:0,c:0,x:0,m:0,d:0}),M={};
  cnt.forEach(a=>{const k=a.date.slice(0,7),m=M[k]||(M[k]=blank());m.t++;if(a.status==='completed')m.c++;if(a.status==='cancelled')m.x++;if(a.status==='missed')m.m++});
  days.forEach(k=>{const m=M[k.slice(0,7)]||(M[k.slice(0,7)]=blank());m.d++});
  const wd=[];
  for(let i=0;i<7;i++){const dd=days.filter(k=>pd(k).getDay()===i).length;if(!dd)continue;
    const g=cnt.filter(a=>pd(a.date).getDay()===i),o=g.filter(occ).length;
    wd.push({i,days:dd,n:g.length,avg:g.length/dd,mis:g.filter(a=>a.status==='missed').length,util:pct1(o,dd*3*CAP)})}
  const sh=SH.map((_,j)=>{const g=cnt.filter(a=>a.shift===j),o=g.filter(occ).length;
    return{j,name:shortSh(j),n:g.length,mis:g.filter(a=>a.status==='missed').length,util:pct1(o,days.length*CAP)}});
  const mc=[];for(let m=1;m<=CAP;m++){const o=cnt.filter(a=>a.machine===m&&occ(a)).length;mc.push({m,util:pct1(o,days.length*3)})}
  const totOcc=cnt.filter(occ).length,
    cur=TODAY.slice(0,7),mk=Object.keys(M).sort();
  let cand=mk.filter(k=>k<cur);if(cand.length<2)cand=mk;
  const ext=(arr,f)=>arr.length<2?null:{hi:arr.reduce((a,b)=>f(b)>f(a)?b:a),lo:arr.reduce((a,b)=>f(b)<f(a)?b:a)};
  return{cnt,tot:cnt.length,done:n('completed'),can:n('cancelled'),mis:n('missed'),unres,first,days,M,mk,wd,sh,mc,
    util:pct1(totOcc,days.length*3*CAP),
    xMonth:ext(cand,k=>M[k].t),xWeek:ext(wd,w=>w.avg),xShift:ext(sh,h=>h.n),curMonthExcluded:cand.every(k=>k<cur)&&mk.includes(cur)}
}

function anUpcoming(){
  const out=[];
  for(let i=1;i<=RULES.soonDays;i++){const d=addD(now,i),k=iso(d);if(!OPEN[d.getDay()]||holName(k))continue;
    for(let j=0;j<3;j++){const b=act(k,j).length;out.push({k,j,b,p:pct1(b,CAP)})}}
  return out
}

function anRules(s){
  const R=[],add=(t,l)=>R.push({t,l});
  if(!s.tot)return[{t:'No past appointments recorded yet. Recommendations appear once sessions have been completed, missed or cancelled.',l:'info'}];
  if(s.days.length<14)add('Only '+s.days.length+' operating days of history so far. Treat these recommendations as early indications.','info');
  /* Utilization: capacity by weekday and shift */
  s.wd.filter(w=>w.util>=RULES.highUtil).sort((a,b)=>b.util-a.util).forEach(w=>add(`${DN[w.i]} runs at ${f0(w.util)}% utilization. Consider adding capacity on ${DN[w.i]} (an extra shift or machine) or offering patients a quieter day.`,'warn'));
  s.sh.filter(h=>h.util>=RULES.highUtil).sort((a,b)=>b.util-a.util).forEach(h=>add(`The ${h.name} shift runs at ${f0(h.util)}% utilization. Offer another shift to patients with flexible schedules, or assign extra staff to it.`,'warn'));
  if(s.wd.length>1){const lw=s.wd.reduce((a,b)=>b.util<a.util?b:a);if(lw.util<RULES.lowUtil)add(`${DN[lw.i]} is the quietest operating day (${f0(lw.util)}% utilization). Offer it first to new and rescheduled patients and review staffing for that day.`,'info')}
  const hs=s.sh.reduce((a,b)=>b.util>a.util?b:a),ls=s.sh.reduce((a,b)=>b.util<a.util?b:a);
  if(ls.util<RULES.lowUtil)add(`The ${ls.name} shift is the least used (${f0(ls.util)}% utilization). Suggest it to new patients to balance the day.`,'info');
  if(hs.util-ls.util>=RULES.shiftGap)add(`Demand is uneven across shifts: ${hs.name} at ${f0(hs.util)}% versus ${ls.name} at ${f0(ls.util)}%. Move flexible patients toward the ${ls.name} shift.`,'warn');
  /* Missed and cancelled appointments */
  const pm=pct1(s.mis,s.tot),pcn=pct1(s.can,s.tot);
  if(pm>=RULES.missedPct)add(`Missed appointments are ${f1(pm)}% (${s.mis} of ${s.tot}). Send a reminder the day before each session.`,'warn');
  const grp=[...s.wd.map(w=>({l:DN[w.i]+' sessions',n:w.n,m:w.mis})),...s.sh.map(h=>({l:'the '+h.name+' shift',n:h.n,m:h.mis}))].filter(g=>g.n>=RULES.minGroup).map(g=>({...g,r:pct1(g.m,g.n)})).sort((a,b)=>b.r-a.r)[0];
  if(grp&&grp.r>=RULES.missedPct&&grp.r>=pm*1.3)add(`Missed sessions are concentrated on ${grp.l} (${f1(grp.r)}% against ${f1(pm)}% overall). Start reminder calls there.`,'warn');
  if(pcn>=RULES.cancelPct)add(`Cancellations are ${f1(pcn)}% (${s.can} of ${s.tot}). Offer cancelled slots to patients with pending requests as soon as they open.`,'warn');
  /* Machines */
  if(s.mc.length>1){const avg=s.mc.reduce((x,m)=>x+m.util,0)/s.mc.length,low=s.mc.filter(m=>avg>0&&m.util<avg*RULES.machineLow);
    if(low.length)add(`Machine${low.length>1?'s':''} ${low.map(m=>m.m).join(', ')} ${low.length>1?'are':'is'} used much less than average (${f0(Math.min(...low.map(m=>m.util)))}% against ${f0(avg)}%). Check whether ${low.length>1?'they are':'it is'} in maintenance or skipped when machines are assigned.`,'info')}
  /* Look-ahead: upcoming load and pending requests */
  const full=anUpcoming().filter(u=>u.p>=RULES.soonFull);
  if(full.length)add(`${full.length} shift${full.length>1?'s':''} in the next ${RULES.soonDays} days ${full.length>1?'are':'is'} at least ${RULES.soonFull}% booked (for example ${full.slice(0,3).map(u=>fmt(u.k)+', '+shortSh(u.j)).join('; ')}). Direct new requests to shifts with open machines or plan an extra session.`,'warn');
  const soon=A.filter(a=>a.status==='pending'&&a.date>=TODAY&&a.date<=iso(addD(now,3))).length;
  if(soon)add(`${soon} pending request${soon>1?'s are':' is'} for the next 3 days. Review ${soon>1?'them':'it'} first.`,'warn');
  if(s.unres)add(`${s.unres} past appointment${s.unres>1?'s have':' has'} no recorded outcome (still pending or confirmed). Mark ${s.unres>1?'them':'it'} completed, missed or cancelled so these figures stay accurate.`,'info');
  if(!R.some(r=>r.l==='warn'))add('No scheduling issues detected under the current rules.','good');
  const o={warn:0,info:1,good:2};return R.sort((a,b)=>o[a.l]-o[b.l])
}

function dash(S){
  const s=anStats(),R=anRules(s),pc=n=>f1(pct1(n,s.tot));
  const kp=[[s.tot,'Appointments'],[s.done,'Completed sessions'],[`${s.can}<em>${pc(s.can)}%</em>`,'Cancelled appointments'],[`${s.mis}<em>${pc(s.mis)}%</em>`,'Missed appointments'],[f0(s.util)+'%','Overall utilization']];
  const xr=(lab,x,fmtFn)=>`<tr><th>${lab}</th><td>${x?fmtFn(x.hi):'Not enough data'}</td><td>${x?fmtFn(x.lo):'Not enough data'}</td></tr>`;
  const since=s.first?new Date(s.first+'T12:00:00').toLocaleDateString('en-PH',{month:'long',day:'numeric',year:'numeric'}):'';
  /* patients with most missed sessions (keys stay as-is so database ids work) */
  const MP=new Map();s.cnt.filter(a=>a.status==='missed'||a.status==='cancelled').forEach(a=>{const m=MP.get(a.pid)||{x:0,c:0};a.status==='missed'?m.x++:m.c++;MP.set(a.pid,m)});
  const top=[...MP.entries()].sort((a,b)=>b[1].x-a[1].x||b[1].c-a[1].c).slice(0,5);
  S.innerHTML=`${annHtml()}<div class="row" style="justify-content:space-between"><h2>Analytics dashboard</h2><button class="btn noprint" onclick="window.print()">Save as PDF report</button></div>
<p class="mut">${s.tot?`Past appointments from ${since} to yesterday: ${s.days.length} operating days, ${CAP} machines, 3 shifts a day.`:'No past appointments yet.'}${window.RDC_SUPABASE_CONNECTED?'':' Preview data.'} Rejected and still-pending requests are not counted as appointments.</p>
<div class="grid kg">${kp.map(k=>`<div class="panel kpi"><b>${k[0]}</b><span>${k[1]}</span></div>`).join('')}</div>
<div class="grid g2" style="margin-top:14px">
<div class="panel"><h3>Appointments and completed sessions per month</h3><div class="chart"><canvas id="c1"></canvas></div></div>
<div class="panel"><h3>Appointment outcomes</h3><div class="chart"><canvas id="c2"></canvas></div></div>
<div class="panel"><h3>Highest and lowest periods</h3><div class="tw"><table><tr><th></th><th>Highest</th><th>Lowest</th></tr>
${xr('Month',s.xMonth,k=>`${MON(k)}: ${s.M[k].t}`)}${xr('Weekday',s.xWeek,w=>`${DN[w.i]}: ${f1(w.avg)} a day (${w.n})`)}${xr('Shift',s.xShift,h=>`${h.name}: ${h.n}`)}</table></div>
<p class="mut" style="margin-top:8px">Counts are appointments. Weekdays are compared by average per operating day so days that occur more often are not favored.${s.curMonthExcluded?' The current month is left out until it ends.':''}</p></div>
<div class="panel"><h3>Recommendations (rule-based)</h3>${R.map(r=>`<div class="rec ${r.l==='warn'?'warn':r.l==='good'?'good':''}">${esc(r.t)}</div>`).join('')}<p class="mut">Suggestions only. They never change schedules or treatment.</p></div>
<div class="panel"><h3>Utilization by weekday (%)</h3><div class="chart"><canvas id="c3"></canvas></div></div>
<div class="panel"><h3>Utilization by shift (%)</h3><div class="chart"><canvas id="c4"></canvas></div></div>
<div class="panel"><h3>Utilization by machine (%)</h3><div class="chart"><canvas id="c5"></canvas></div></div>
<div class="panel"><h3>New patient registrations per month</h3><div class="chart"><canvas id="c6"></canvas></div></div>
</div>
<div class="panel" style="margin-top:14px"><h3>Appointments by month</h3><div class="tw"><table><tr><th>Month</th><th>Appointments</th><th>Completed</th><th>Cancelled</th><th>Missed</th><th>Average per operating day</th></tr>${s.mk.map(k=>{const m=s.M[k];return`<tr><td>${MON(k)}${k===TODAY.slice(0,7)?' (in progress)':''}</td><td>${m.t}</td><td>${m.c}</td><td>${m.x} (${f1(pct1(m.x,m.t))}%)</td><td>${m.m} (${f1(pct1(m.m,m.t))}%)</td><td>${m.d?f1(m.t/m.d):'-'}</td></tr>`}).join('')||'<tr><td colspan="6">No data yet.</td></tr>'}</table></div></div>
<div class="panel" style="margin-top:14px"><h3>Patients with the most missed sessions</h3><div class="tw"><table><tr><th>Patient</th><th>Missed</th><th>Cancelled</th></tr>${top.map(r=>`<tr><td>${esc(P(r[0]).name)}</td><td>${r[1].x}</td><td>${r[1].c}</td></tr>`).join('')||'<tr><td colspan="3">None.</td></tr>'}</table></div><p class="mut">Useful for deciding who to call with reminders.</p></div>
<p class="mut" style="margin-top:14px">Utilization is completed plus missed sessions divided by the machine-sessions available on operating days (holidays and closed days excluded; today's machine count is used for all dates). Rule thresholds: high use ${RULES.highUtil}% or more, low use under ${RULES.lowUtil}%, missed ${RULES.missedPct}% or more, cancelled ${RULES.cancelPct}% or more.</p>`;
  if(!window.Chart)return;
  const st=getComputedStyle(document.documentElement),B=st.getPropertyValue('--blue').trim(),Rd=st.getPropertyValue('--red').trim(),Ok=st.getPropertyValue('--ok').trim(),T=st.getPropertyValue('--ink').trim();
  Chart.defaults.color=T;
  const mk=(id,type,data,o)=>charts.push(new Chart($(id),{type,data,options:{responsive:true,maintainAspectRatio:false,...o}})),
    UO={plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,suggestedMax:100,ticks:{callback:v=>v+'%'}}}},
    one=(label,data)=>({datasets:[{label,data,backgroundColor:B}]});
  mk('#c1','bar',{labels:s.mk.map(MON),datasets:[{label:'Appointments',data:s.mk.map(k=>s.M[k].t),backgroundColor:B},{label:'Completed',type:'line',data:s.mk.map(k=>s.M[k].c),borderColor:Rd,backgroundColor:Rd}]});
  mk('#c2','doughnut',{labels:['Completed','Cancelled','Missed'],datasets:[{data:[s.done,s.can,s.mis],backgroundColor:[Ok,'#e0a030',Rd]}]});
  mk('#c3','bar',{labels:s.wd.map(w=>DN[w.i]),...one('Utilization %',s.wd.map(w=>f0(w.util)))},UO);
  mk('#c4','bar',{labels:s.sh.map(h=>h.name),...one('Utilization %',s.sh.map(h=>f0(h.util)))},UO);
  mk('#c5','bar',{labels:s.mc.map(m=>'M'+m.m),...one('Utilization %',s.mc.map(m=>f0(m.util)))},UO);
  const NP={};patients.forEach(p=>{const k=(p.joined||TODAY).slice(0,7);NP[k]=(NP[k]||0)+1});const nk=Object.keys(NP).sort();
  mk('#c6','bar',{labels:nk.map(MON),...one('New patients',nk.map(k=>NP[k]))},{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}});
}

/* =====================================================================
   OBJECTIVE 1 - Staff appointment calendar = the Requests tab
   Each day shows how full it is and how many requests are waiting; selecting a day
   lets staff approve or reject requests and cancel/reschedule requests in place.
   ===================================================================== */
let sm=null,sdSel=null,RV='week',sw=null;
const idJ=x=>typeof x==='number'?x:JSON.stringify(x).replace(/"/g,'&quot;');
const mondayOf=d=>{const x=new Date(d);x.setHours(0,0,0,0);x.setDate(x.getDate()-((x.getDay()+6)%7));return x},
  shiftTimes=['8:00–11:00 AM','11:00 AM–2:00 PM','2:00–5:00 PM'];
function goDay(k){sdSel=k;sm=new Date(+k.slice(0,4),+k.slice(5,7)-1,1);sw=mondayOf(pd(k))}
function closeAppointmentDocs(){const modal=$('#apdoc');if(modal)modal.remove();document.removeEventListener('keydown',appointmentDocsKey)}
function appointmentDocsKey(e){if(e.key==='Escape')closeAppointmentDocs()}
function appointmentDetailsHtml(p,a,docs){
  const m=p.med||{},value=v=>esc(v||'-'),row=(label,v)=>`<div class="apdoc-field"><b>${label}</b><span>${value(v)}</span></div>`,
    docList=docs.length?`<div class="apdoc-list">${docs.map(d=>{
      const status=d.status||'submitted',validUrl=d.url&&/^(https?:|blob:|data:application\/pdf|data:image\/)/i.test(d.url);
      return`<div class="apdoc-item"><div><b>${esc(d.k||d.document_type||'Document')}</b><span>${esc(d.name||d.file_name||'Uploaded file')}</span><small>${esc(status.replace(/_/g,' '))}${d.validation_result==='passed'?' · checks passed':''}</small></div>${validUrl?`<a class="btn ghost sm" href="${esc(d.url)}" target="_blank" rel="noopener">View file</a>`:'<span class="mut">File unavailable</span>'}</div>`}).join('')}</div>`:'<p class="mut">No submitted documents.</p>',
    labs=(p.labs||[]).length?`<div class="tw"><table><tr><th>Test</th><th>Result</th><th>Date</th></tr>${p.labs.map(l=>`<tr><td>${value(l.t||l.test)}</td><td>${value(l.v||l.result)}</td><td>${value(l.d?fmt(l.d):l.date?fmt(l.date):'')}</td></tr>`).join('')}</table></div>`:'<p class="mut">No laboratory results on file.</p>',
    history=A.filter(x=>x.pid===p.id).sort((x,y)=>y.date.localeCompare(x.date)).slice(0,12);
  return`<div class="apdoc-section"><h3>Patient details</h3><div class="apdoc-fields">${row('Verification',p.ver)}${row('Gender',p.gender)}${row('Date of birth',p.dob)}${row('Civil status',p.cs)}${row('Contact number',p.contact)}${row('Address',p.adr)}${row('Emergency contact',p.em)}${row('PhilHealth number',p.phn)}</div></div>
<div class="apdoc-section"><h3>Medical information</h3><div class="apdoc-fields">${row('Blood type',m.bt)}${row('Kidney condition',m.dx)}${row('Nephrologist / hospital',m.rp)}${row('Dialysis started',m.ds)}${row('Dialysis access',m.va)}${row('Preferred schedule',m.pf)}${row('Allergies',m.al)}${row('Current medications',m.md)}${row('Other conditions',m.cm)}${row('Latest lab date',m.lab)}</div></div>
<div class="apdoc-section"><h3>Record notes</h3><p>${value(p.notes)}</p></div>
<div class="apdoc-section"><h3>Laboratory results</h3>${labs}</div>
<div class="apdoc-section"><h3>Appointment and session history</h3>${history.length?`<div class="tw"><table><tr><th>Date</th><th>Shift</th><th>Status</th><th>Treatment details</th></tr>${history.map(x=>{const tx=x.tx||{},details=[['Weight before',tx.pre??tx.weight_before],['Weight after',tx.post??tx.weight_after],['Blood pressure',tx.bp??tx.blood_pressure],['Duration',tx.dur??tx.duration_hours],['Notes',tx.note??tx.notes]].filter(([,v])=>v).map(([k,v])=>`${k}: ${v}`).join(' · ');return`<tr><td>${value(fmt(x.date))}</td><td>${value(SH[x.shift])}</td><td>${tag(x.status)}</td><td>${value(details)}</td></tr>`}).join('')}</table></div>`:'<p class="mut">No appointments on file.</p>'}</div>
<div class="apdoc-section"><h3>Submitted documents</h3>${docList}</div>
${me.role==='staff'&&a.status==='pending'?`<div class="apdoc-actions"><button class="btn red" onclick="rejectAppointmentFromDetails(${idJ(a.id)})">Reject request</button><button class="btn" onclick="approveAppointmentFromDetails(${idJ(a.id)})">Approve request</button></div>`:me.role==='staff'&&a.rq?`<div class="apdoc-actions"><button class="btn red" onclick="processAppointmentChangeFromDetails(${idJ(a.id)},0)">Reject change</button><button class="btn" onclick="processAppointmentChangeFromDetails(${idJ(a.id)},1)">Approve change</button></div>`:''}`;
}
function approveAppointmentFromDetails(id){
  const a=A.find(x=>x.id===id),p=a&&P(a.pid);
  if(!a)return toast('Appointment not found.');
  if(p&&['none','pending','incomplete','not_submitted'].includes(p.ver)){appr(id);return}
  closeAppointmentDocs();appr(id);
}
function rejectAppointmentFromDetails(id){if(!A.some(x=>x.id===id))return toast('Appointment not found.');closeAppointmentDocs();setS(id,'declined')}
function processAppointmentChangeFromDetails(id,approve){if(!A.some(x=>x.id===id))return toast('Appointment not found.');closeAppointmentDocs();procRq(id,approve)}
async function openAppointmentDocuments(id){
  const a=A.find(x=>x.id===id);if(!a)return toast('Appointment not found.');
  const p=P(a.pid);sdSel=a.date;scal($('#s'));
  closeAppointmentDocs();
  const modal=document.createElement('div');modal.id='apdoc';modal.className='apdoc';modal.innerHTML=`<section class="apdoc-card" role="dialog" aria-modal="true" aria-labelledby="apdoct"><div class="apdoc-head"><div><h2 id="apdoct">${esc(p.name)}</h2><p>Appointment: ${esc(fmt(a.date))} · ${esc(SH[a.shift])} · ${esc(a.status)}</p></div><button type="button" class="apdoc-close" aria-label="Close patient details" onclick="closeAppointmentDocs()">×</button></div><div class="apdoc-body" aria-live="polite">Loading patient details…</div></section>`;
  modal.addEventListener('click',e=>{if(e.target===modal)closeAppointmentDocs()});
  document.body.appendChild(modal);document.addEventListener('keydown',appointmentDocsKey);
  try{
    const docs=window.rdcGetPatientDocuments?await window.rdcGetPatientDocuments(p.id):(p.docs||[]);
    if(!modal.isConnected)return;
    modal.querySelector('.apdoc-body').innerHTML=appointmentDetailsHtml(p,a,docs);
    modal.querySelector('.apdoc-close').focus();
  }catch(err){
    console.error('[Reliance] Unable to load patient documents.',err);
    modal.querySelector('.apdoc-body').innerHTML='<p class="rec warn">Unable to load the patient documents. Check the connection and document access permissions, then try again.</p>';
    toast(err?.message||'Unable to load patient documents.');
  }
}
const reqToggle=()=>`<div class="row noprint" style="margin:6px 0 12px"><button class="btn sm ${RV==='week'?'':'ghost'}" onclick="RV='week';go(view)">Week</button><button class="btn sm ${RV==='month'?'':'ghost'}" onclick="RV='month';go(view)">Month</button><button class="btn sm ${RV==='list'?'':'ghost'}" onclick="RV='list';go(view)">List</button></div>`;
function scal(S){
  const m=sm||(sm=new Date(now.getFullYear(),now.getMonth(),1)),y=m.getFullYear(),mo=m.getMonth(),ym=y+'-'+String(mo+1).padStart(2,'0'),
    lead=new Date(y,mo,1).getDay(),nd=new Date(y,mo+1,0).getDate(),cap=CAP*3,held=['pending','confirmed','completed','missed'];
  const by={};A.forEach(a=>{if(a.date)(by[a.date]=by[a.date]||[]).push(a)});
  const mine=Object.values(by).flat().filter(a=>a.date.startsWith(ym)),cntS=s=>mine.filter(a=>a.status===s).length,
    todo={};A.forEach(a=>{if(a.date>=TODAY&&(a.status==='pending'||a.rq))todo[a.date]=(todo[a.date]||0)+1});
  const chips=Object.keys(todo).sort().slice(0,10);
  let c=DN.map(d=>`<div class="wd">${d}</div>`).join('')+'<div></div>'.repeat(lead);
  for(let d=1;d<=nd;d++){
    const k=ym+'-'+String(d).padStart(2,'0'),hn=holName(k);
    if(hn){c+=`<div class="cd off hol" title="${esc(hn)}" aria-label="${fmt(k)}, closed for ${esc(hn)}">${d}<small>Closed</small></div>`;continue}
    if(!OPEN[new Date(y,mo,d).getDay()]){c+=`<div class="cd off">${d}</div>`;continue}
    const L=by[k]||[],o=L.filter(a=>held.includes(a.status)).length,pe=L.filter(a=>a.status==='pending').length,ch=L.filter(a=>a.rq).length,p=pct1(o,cap),
      cls=p>=90?'ld3':p>=70?'ld2':p>=40?'ld1':'ld0';
    c+=`<button class="cd sc ${cls} ${pe||ch?'hasp':''} ${sdSel===k?'sel':''}" onclick="sdSel='${k}';scal($('#s'))" aria-label="${fmt(k)}, ${o} of ${cap} machine sessions booked${pe?', '+pe+' pending requests':''}${ch?', '+ch+' change requests':''}">${d}<small>${o}/${cap}</small>${pe?`<i class="pdg">${pe} pending</i>`:''}${ch?`<i class="pdg">${ch} change</i>`:''}</button>`}
  let det='';
  if(sdSel){
    const L=(by[sdSel]||[]).filter(a=>a.status!=='declined'),isT=sdSel<=TODAY,
      free=(a,mm)=>!act(a.date,a.shift).some(x=>x.machine===mm),
      need=a=>a.status==='pending'||a.rq?0:1,
      row=a=>{const p=P(a.pid);let mc=a.machine||'-',ac='';
        if(a.status==='pending'){mc=`<select id="mc${a.id}" aria-label="Machine" style="width:auto;padding:6px 8px"><option value="auto">Auto</option>${Array.from({length:CAP},(_,i)=>i+1).filter(mm=>free(a,mm)).map(mm=>`<option value="${mm}">Machine ${mm}</option>`).join('')}</select>`;
          ac=`<button class="btn sm" onclick="appr(${idJ(a.id)})">Approve</button><button class="btn red sm" onclick="setS(${idJ(a.id)},'declined')">Reject</button>`}
        else if(a.rq)ac=`<button class="btn sm" onclick="procRq(${idJ(a.id)},1)">Approve ${a.rq.type==='cancel'?'cancellation':'move'}</button><button class="btn red sm" onclick="procRq(${idJ(a.id)},0)">Reject</button>`;
        else if(a.status==='confirmed'&&isT)ac=`<button class="btn sm" onclick="setS(${idJ(a.id)},'completed')">Done</button><button class="btn red sm" onclick="setS(${idJ(a.id)},'missed')">Missed</button>`;
        const unv=a.status==='pending'&&verOf(p)!=='verified'?`<br><span class="mut">Requirements not verified. <a href="#" style="color:var(--blue)" onclick="sel=${idJ(p.id)};Object.assign(RF,{q:'',ver:'all',lab:'all'});tab='rec';go(view);return false">Open record</a></span>`:'';
        return`<tr><td>${mc}</td><td>${esc(p.name)}${unv}</td><td>${tag(a.status)}${a.rq?`<div class="mut">${a.rq.type==='cancel'?'Cancellation requested':'Move to '+esc(fmt(a.rq.date))+', '+shortSh(a.rq.shift)}</div>`:''}</td><td><div class="row" style="flex-wrap:nowrap">${ac}</div></td></tr>`};
    det=`<div class="panel" style="margin-top:14px"><h3>${esc(fmt(sdSel))}, ${sdSel.slice(0,4)}</h3>${SH.map((sn,j)=>{
      const g=L.filter(a=>a.shift===j).sort((a,b)=>need(a)-need(b)||(a.machine||99)-(b.machine||99)),o=g.filter(a=>held.includes(a.status)).length,pe=g.filter(a=>a.status==='pending').length;
      return`<div style="margin:12px 0 4px" class="row"><b>${sn}</b><span class="mut">${o} of ${CAP} machines booked${pe?', '+pe+' pending':''}</span><button class="btn ghost sm noprint" onclick="mdate='${sdSel}';mshift=${j};tab='mach';go(view)">Machine view</button></div>
      <div class="tw"><table><tr><th>Machine</th><th>Patient</th><th>Status</th><th>Action</th></tr>${g.map(row).join('')||'<tr><td colspan="4">No appointments.</td></tr>'}</table></div>`}).join('')}</div>`}
  const weekStart=sw||(sw=mondayOf(now)),weekDays=Array.from({length:6},(_,i)=>{const d=new Date(weekStart);d.setDate(d.getDate()+i);return iso(d)}),
    rangeLabel=`${fmt(weekDays[0])} – ${fmt(weekDays[5])}`,
    weekGrid=`<div class="week-scroll"><div class="week-grid"><div class="week-corner">PH time</div>${weekDays.map(k=>`<div class="week-head"><b>${pd(k).toLocaleDateString('en',{weekday:'short'})}</b><span>${pd(k).toLocaleDateString('en',{month:'short',day:'numeric'})}</span><small>${(by[k]||[]).filter(a=>held.includes(a.status)).length}/3 appointments</small></div>`).join('')}${SH.map((sn,j)=>`<div class="week-time"><b>${shiftTimes[j]}</b><span>${sn}</span></div>${weekDays.map(k=>{const holiday=holName(k),closed=holiday||!OPEN[pd(k).getDay()],events=(by[k]||[]).filter(a=>a.shift===j&&a.status!=='declined').sort((a,b)=>a.date.localeCompare(b.date));return`<div class="week-slot${closed?' off':''}">${closed?`<span class="week-closed">${esc(holiday||'Closed')}</span>`:events.map(a=>`<button class="week-event ${a.status==='pending'?'pending':a.status==='confirmed'?'confirmed':a.status==='cancelled'||a.status==='missed'?'cancelled':'completed'}" onclick="openAppointmentDocuments(${idJ(a.id)})" title="View ${esc(P(a.pid).name)}'s documents"><b>${esc(P(a.pid).name)}</b></button>`).join('')||'<span class="week-empty">No appointments</span>'}</div>`}).join('')}`).join('')}</div></div>`,
    calendar=RV==='week'?`<div class="card"><div class="bk-h"><h3>${rangeLabel}</h3><div class="bk-nav noprint"><button class="btn ghost sm" onclick="sw.setDate(sw.getDate()-7);sdSel=null;scal($('#s'))" aria-label="Previous week">&larr;</button><button class="btn ghost sm" onclick="sw=mondayOf(now);sdSel=null;scal($('#s'))">This week</button><button class="btn ghost sm" onclick="sw.setDate(sw.getDate()+7);sdSel=null;scal($('#s'))" aria-label="Next week">&rarr;</button></div></div>${weekGrid}<div class="week-legend"><span>Pending</span><span>Confirmed</span><span>Completed</span><span>Cancelled / missed</span></div></div>`:
      `<div class="card"><div class="bk-h"><h3>${m.toLocaleString('en',{month:'long',year:'numeric'})}</h3><div class="bk-nav noprint"><button class="btn ghost sm" onclick="sm=new Date(${y},${mo-1},1);scal($('#s'))" aria-label="Earlier month">&larr;</button><button class="btn ghost sm" onclick="sm=null;sdSel=null;scal($('#s'))">This month</button><button class="btn ghost sm" onclick="sm=new Date(${y},${mo+1},1);scal($('#s'))" aria-label="Later month">&rarr;</button></div></div><p class="mut" style="margin:4px 0 0">This month: ${mine.filter(a=>held.includes(a.status)).length} booked, ${cntS('pending')} pending, ${cntS('completed')} completed, ${cntS('cancelled')} cancelled, ${cntS('missed')} missed.</p><div class="cal">${c}</div><div class="leg"><span><i style="background:#f4f8fe;border:1px solid #d6e4f7"></i>Under 40% booked</span><span><i style="background:#dbe9fb;border:1px solid #a9c6ee"></i>40 to 69%</span><span><i style="background:#b5d0f5;border:1px solid #6f9fe0"></i>70 to 89%</span><span><i style="background:#f7c9c9;border:1px solid #e08a8a"></i>90% or more</span><span><i style="background:#fff;border:1px solid #d6e4f7;box-shadow:inset 0 -3px 0 var(--warn)"></i>Has requests to review</span><span><i style="background:#eceff4;border:1px dashed #9aa8bd"></i>Closed or holiday</span></div></div>`;
  S.innerHTML=`${annHtml()}<h2>Appointment requests</h2>${reqToggle()}<p class="mut" style="margin-top:0">Review appointment requests by week, month, or list. Select a week appointment to review its details and actions.</p>
${chips.length?`<div class="row noprint" style="margin:0 0 12px"><span class="mut">Needs action:</span>${chips.map(k=>`<button class="btn ghost sm" onclick="goDay('${k}');scal($('#s'))">${esc(fmt(k))} (${todo[k]})</button>`).join('')}</div>`:'<p class="mut">No requests are waiting.</p>'}
${calendar}${det}`;
}
TABS.staff=[['sdash','Dashboard'],['req','Requests'],['mach','Machines and slots'],['rec','Patient records']];
{const app3=app,EX={sdash:sdash};app=V=>{const t=tab,fn=me.role==='staff'?EX[t]:null;if(fn)tab='req';app3(V);tab=t;
  if(fn){V.querySelectorAll('.side button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));fn($('#s'))}}}
{const req0=req;req=S=>{if(RV==='list'){req0(S);const h=S.querySelector('h2');if(h)h.insertAdjacentHTML('afterend',reqToggle());return}scal(S)}}

/* =====================================================================
   OBJECTIVE 2 - Patient records: search, filter, sort
   ===================================================================== */
const RF={q:'',ver:'all',lab:'all',sort:'name'},
  verOf=p=>p.ver||'not_submitted',
  VL={not_submitted:'not submitted',pending:'pending review',verified:'verified',incomplete:'incomplete'},
  hasLab=p=>!!(p.med&&p.med.lab);
function rl(v){
  if(typeof v==='string')RF.q=v;
  const el=$('#rl');if(!el)return;
  const info={};A.forEach(a=>{const o=info[a.pid]||(info[a.pid]={n:0,last:''});
    if(a.status==='completed')o.n++;
    if((a.status==='completed'||a.status==='missed')&&a.date<=TODAY&&a.date>o.last)o.last=a.date});
  const I=p=>info[p.id]||{n:0,last:''},q=RF.q.trim().toLowerCase();
  let l=patients.filter(p=>{
    if(q&&![p.name,p.email,p.contact,p.phn].some(x=>String(x||'').toLowerCase().includes(q)))return false;
    if(RF.ver!=='all'&&verOf(p)!==RF.ver)return false;
    if(RF.lab==='old'&&!labOld(p))return false;
    if(RF.lab==='ok'&&!(hasLab(p)&&!labOld(p)))return false;
    if(RF.lab==='none'&&hasLab(p))return false;
    return true});
  const vo={pending:0,incomplete:1,not_submitted:2,verified:3};
  l.sort({
    name:(a,b)=>a.name.localeCompare(b.name),
    ver:(a,b)=>vo[verOf(a)]-vo[verOf(b)]||a.name.localeCompare(b.name),
    lab:(a,b)=>(hasLab(a)?a.med.lab:'')<(hasLab(b)?b.med.lab:'')?-1:(hasLab(a)?a.med.lab:'')>(hasLab(b)?b.med.lab:'')?1:a.name.localeCompare(b.name),
    recent:(a,b)=>I(b).last.localeCompare(I(a).last)||a.name.localeCompare(b.name)
  }[RF.sort]||((a,b)=>a.name.localeCompare(b.name)));
  const vt=p=>`<span class="tag ${verOf(p)==='verified'?'completed':verOf(p)==='incomplete'?'cancelled':'pending'}">${esc(VL[verOf(p)]||verOf(p))}</span>`;
  el.innerHTML=l.map(p=>`<div style="margin:3px 0 8px"><button class="btn ghost sm ${sel===p.id?'rlsel':''}" style="width:100%;text-align:left" ${sel===p.id?'aria-current="true"':''} onclick="sel=${typeof p.id==='number'?p.id:JSON.stringify(p.id).replace(/"/g,'&quot;')};rec($('#s'))">${esc(p.name)}</button><div class="mut" style="margin:2px 0 0 4px">${vt(p)}${labOld(p)?' <span class="tag cancelled">lab over 7 days old</span>':''}<br>${I(p).n} completed session${I(p).n===1?'':'s'}${I(p).last?', last '+esc(fmt(I(p).last)):''}</div></div>`).join('')||'<p class="mut">No patients match these filters.</p>';
  const c=$('#rfc');if(c)c.textContent=`Showing ${l.length} of ${patients.length} patients. ${patients.filter(p=>verOf(p)==='pending').length} awaiting review; ${patients.filter(p=>labOld(p)).length} with lab results older than 7 days.`;
}
{const rc3=rec;rec=S=>{const keep=RF.q;rc3(S);
  const inp=S.querySelector('input[aria-label="Search"]');if(!inp)return;
  inp.value=keep;inp.placeholder='Search name, email, contact or PhilHealth number';
  const sel2=(id,lab,cur,opts)=>`<select aria-label="${lab}" style="width:auto" onchange="RF.${id}=this.value;rl()">${opts.map(o=>`<option value="${o[0]}" ${o[0]===cur?'selected':''}>${o[1]}</option>`).join('')}</select>`;
  inp.insertAdjacentHTML('afterend',`<div class="row noprint" style="margin-top:10px">
${sel2('ver','Verification status',RF.ver,[['all','All verification statuses'],['pending','Pending review'],['incomplete','Incomplete'],['not_submitted','Not submitted'],['verified','Verified']])}
${sel2('lab','Laboratory results',RF.lab,[['all','Any lab date'],['old','Lab results over 7 days old'],['ok','Lab results within 7 days'],['none','No lab date on file']])}
${sel2('sort','Sort by',RF.sort,[['name','Sort: name'],['ver','Sort: needs review first'],['lab','Sort: oldest lab first'],['recent','Sort: latest session']])}
<button class="btn ghost sm" onclick="Object.assign(RF,{q:'',ver:'all',lab:'all',sort:'name'});rec($('#s'))">Clear filters</button></div><p class="mut" id="rfc" style="margin:8px 0 0"></p>`);
  rl(keep)}}

/* =====================================================================
   Notifications: clicking an item opens the page it is about.
   Notifications are stored as text, so the destination is worked out from the message.
   ===================================================================== */
function nlTarget(n){
  const m=n.m||'',who=patients.filter(p=>m.startsWith(p.name)).sort((a,b)=>b.name.length-a.name.length)[0];
  if(me.role==='staff'){
    if(/attached|uploaded|submitted|completed their profile|medical record/i.test(m))return{tab:'rec',pid:who&&who.id};
    if(/requested|asked to|cancelled|rescheduled|changed a pending/i.test(m)){const matches=a=>a.pid===who?.id&&(a.status==='pending'||a.rq)&&[a.date,a.rq?.date].some(d=>d&&m.includes(fmt(d))),pa=(who&&A.find(matches))||(who&&A.filter(a=>a.pid===who.id&&(a.status==='pending'||a.rq)&&a.date>=TODAY).sort((x,y)=>x.date.localeCompare(y.date))[0]);return{tab:'req',day:pa&&(pa.rq?.date||pa.date)}}
    if(/New patient account/i.test(m))return{tab:'rec'};
    return{tab:'req'}}
  if(me.role==='admin')return{tab:/New patient account/i.test(m)?'users':/Announcement/i.test(m)?'ann':'dash'};
  if(/medical record|laboratory|Treatment details|resubmit/i.test(m))return{tab:'med'};
  if(/slot opened/i.test(m))return{tab:'book'};
  if(/Announcement|Reminder/i.test(m))return{tab:'pdash'};
  return{tab:'mine'}
}
function nlRead(i){
  const n=N.filter(mineN)[i];if(!n)return;
  if(!n.read){n.read=1;if(window.rdcMarkRead)window.rdcMarkRead()}
  const t=nlTarget(n);closeNL();
  if(t.pid!==undefined&&t.pid!==null){sel=t.pid;Object.assign(RF,{q:'',ver:'all',lab:'all'})}
  if(t.day){goDay(t.day);RV='week'}
  tab=t.tab;go(view)
}

/* The "new notification" popup gets a View button that opens the same page. */
{const sn0=showN;showN=function(){sn0();
  const n=NQ[0],ok=$('#nmok');if(!n||!ok||!me)return;
  const v=document.createElement('button');v.type='button';v.className='btn ghost nm-ok';v.style.marginTop='8px';v.textContent='View';
  v.onclick=()=>{const t=nlTarget(n);if(t.pid!==undefined&&t.pid!==null){sel=t.pid;Object.assign(RF,{q:'',ver:'all',lab:'all'})}if(t.day){goDay(t.day);RV='week'}tab=t.tab;dismissN();go(view)};
  ok.insertAdjacentElement('afterend',v)}}

/* =====================================================================
   Staff dashboard: today's work at a glance
   ===================================================================== */
function sdash(S){
  const id=x=>typeof x==='number'?x:JSON.stringify(x).replace(/"/g,'&quot;'),
    held=['pending','confirmed','completed','missed'],dow=now.getDay(),hn=holName(TODAY),open=OPEN[dow]&&!hn,
    td=A.filter(a=>a.date===TODAY),booked=td.filter(a=>held.includes(a.status)).length,
    pend=A.filter(a=>a.status==='pending'&&a.date>=TODAY).sort((a,b)=>a.date.localeCompare(b.date)),
    urgent=pend.filter(a=>a.date<=iso(addD(now,3))).length,
    chg=A.filter(a=>a.rq),
    review=patients.filter(p=>verOf(p)==='pending'),
    labs=patients.filter(p=>labOld(p)),
    attn=patients.filter(p=>verOf(p)==='pending'||labOld(p)).slice(0,5),
    kp=[[open?booked+'/'+CAP*3:'Closed',"Today's sessions booked"],[pend.length,'Pending requests'+(urgent?` (${urgent} within 3 days)`:'')],[chg.length,'Cancel or reschedule requests'],[review.length,'Records awaiting review'],[labs.length,'Lab results over 7 days old']],
    soon=[];
  for(let i=1;i<=7;i++){const d=addD(now,i),k=iso(d);if(!OPEN[d.getDay()]||holName(k))continue;
    const b=[0,1,2].reduce((x,j)=>x+act(k,j).length,0);soon.push({k,b,p:pct1(b,CAP*3),pe:A.filter(a=>a.date===k&&a.status==='pending').length})}
  const todayHtml=!open?`<p class="mut">${hn?'The center is closed today for '+esc(hn)+'.':'The center is closed today.'}</p>`:SH.map((sn,j)=>{
    const g=td.filter(a=>a.shift===j&&a.status!=='declined'&&a.status!=='cancelled').sort((a,b)=>(a.machine||99)-(b.machine||99)),o=g.filter(a=>held.includes(a.status)).length;
    return`<div class="row" style="margin:12px 0 4px"><b>${sn}</b><span class="mut">${o} of ${CAP} machines booked</span><button class="btn ghost sm noprint" onclick="mdate='${TODAY}';mshift=${j};tab='mach';go(view)">Machine view</button></div>
<div class="tw"><table><tr><th>Machine</th><th>Patient</th><th>Status</th><th></th></tr>${g.map(a=>`<tr><td>${a.machine||'-'}</td><td>${esc(P(a.pid).name)}</td><td>${tag(a.status)}</td><td>${a.status==='confirmed'?`<div class="row" style="flex-wrap:nowrap"><button class="btn sm" onclick="setS(${id(a.id)},'completed')">Done</button><button class="btn red sm" onclick="setS(${id(a.id)},'missed')">Missed</button></div>`:''}</td></tr>`).join('')||'<tr><td colspan="4">No appointments.</td></tr>'}</table></div>`}).join('');
  S.innerHTML=`${annHtml()}<h2>Staff dashboard</h2><p class="mut">${esc(fmt(TODAY))}, ${TODAY.slice(0,4)}. ${CAP} machines, 3 shifts a day.</p>
<div class="grid kg">${kp.map(k=>`<div class="panel kpi"><b>${k[0]}</b><span>${k[1]}</span></div>`).join('')}</div>
<div class="row noprint" style="margin-top:14px"><button class="btn" onclick="tab='req';go(view)">Review requests</button><button class="btn ghost" onclick="tab='mach';go(view)">Machines and slots</button><button class="btn ghost" onclick="tab='rec';go(view)">Patient records</button></div>
<div class="panel" style="margin-top:14px"><h3>Today's schedule</h3>${todayHtml}</div>
<div class="grid g2" style="margin-top:14px">
<div class="panel"><h3>Requests to review</h3><div class="tw"><table><tr><th>Patient</th><th>Date</th><th>Shift</th><th>Left</th><th></th></tr>${pend.slice(0,6).map(a=>`<tr><td>${esc(P(a.pid).name)}</td><td>${fmt(a.date)}</td><td>${shortSh(a.shift)}</td><td>${left(a.date,a.shift)}</td><td><button class="btn ghost sm" onclick="goDay('${a.date}');tab='req';RV='week';go(view)">Review</button></td></tr>`).join('')||'<tr><td colspan="5">No pending requests.</td></tr>'}</table></div>${pend.length>6?`<p class="mut">${pend.length-6} more in Requests.</p>`:''}${chg.length?`<p class="mut">${chg.length} cancel or reschedule request${chg.length>1?'s':''} also waiting in Requests.</p>`:''}</div>
<div><div class="panel"><h3>Records needing attention</h3>${attn.map(p=>`<div class="row" style="justify-content:space-between;margin:6px 0"><span>${esc(p.name)} <span class="mut">${verOf(p)==='pending'?'awaiting review':''}${verOf(p)==='pending'&&labOld(p)?', ':''}${labOld(p)?'lab over 7 days old':''}</span></span><button class="btn ghost sm" onclick="sel=${id(p.id)};Object.assign(RF,{q:'',ver:'all',lab:'all'});tab='rec';go(view)">Open</button></div>`).join('')||'<p class="mut">Nothing needs attention.</p>'}</div>
<div class="panel" style="margin-top:14px"><h3>Next 7 operating days</h3>${soon.map(d=>`<div style="margin:8px 0"><div class="row" style="justify-content:space-between"><span>${esc(fmt(d.k))}</span><span class="mut">${d.b}/${CAP*3} booked${d.pe?', '+d.pe+' pending':''}</span></div><div style="background:var(--bg2);border-radius:6px;height:8px;margin-top:3px"><div style="width:${Math.min(100,d.p)}%;background:${d.p>=90?'var(--red)':'var(--blue)'};height:8px;border-radius:6px"></div></div></div>`).join('')||'<p class="mut">No operating days in the next week.</p>'}</div></div></div>`;
}
