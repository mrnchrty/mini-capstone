-- Reliance Dialysis Center Inc. schema
-- Core entities follow the supplied ERD: users, patients, medical_records,
-- schedules, appointment_slots, appointments, dialysis_sessions,
-- dialysis_machines and audit_logs. `users.role` stores the role shown in DFD D2.

create extension if not exists pgcrypto;

create table if not exists public.users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  role text not null default 'patient' check (role in ('patient','staff','admin')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.patients (
  patient_id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users(user_id) on delete cascade,
  gender text,
  date_of_birth date,
  civil_status text,
  address text,
  contact_number text,
  emergency_contact_name text,
  emergency_contact_number text,
  philhealth_number text,
  verification_status text not null default 'not_submitted'
    check (verification_status in ('not_submitted','pending','verified','incomplete')),
  created_at timestamptz not null default now()
);

create table if not exists public.medical_records (
  record_id uuid primary key default gen_random_uuid(),
  patient_id uuid not null unique references public.patients(patient_id) on delete cascade,
  blood_type text,
  kidney_condition text,
  attending_nephrologist text,
  dialysis_start_date date,
  dialysis_access text,
  preferred_schedule text,
  allergies text,
  current_medications text,
  other_conditions text,
  latest_lab_date date,
  administrative_notes text,
  laboratory_results jsonb not null default '[]'::jsonb,
  document_manifest jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.dialysis_machines (
  machine_id uuid primary key default gen_random_uuid(),
  machine_number integer not null unique check (machine_number between 1 and 30),
  machine_status text not null default 'active' check (machine_status in ('active','inactive','maintenance')),
  availability_status text not null default 'available' check (availability_status in ('available','unavailable'))
);

create table if not exists public.schedules (
  schedule_id uuid primary key default gen_random_uuid(),
  staff_id uuid references public.users(user_id) on delete set null,
  operating_day smallint not null check (operating_day between 0 and 6),
  shift_number smallint not null check (shift_number between 1 and 3),
  opening_time time not null,
  closing_time time not null,
  status text not null default 'active' check (status in ('active','inactive')),
  unique (operating_day, shift_number),
  check (closing_time > opening_time)
);

create table if not exists public.appointment_slots (
  slot_id uuid primary key default gen_random_uuid(),
  schedule_id uuid not null references public.schedules(schedule_id) on delete cascade,
  appointment_date date not null,
  machine_id uuid not null references public.dialysis_machines(machine_id),
  available_capacity integer not null default 1 check (available_capacity >= 0),
  unique (schedule_id, appointment_date, machine_id)
);

create table if not exists public.appointments (
  appointment_id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(patient_id) on delete cascade,
  slot_id uuid not null references public.appointment_slots(slot_id),
  appointment_status text not null default 'pending'
    check (appointment_status in ('pending','confirmed','completed','cancelled','missed','declined')),
  change_request_type text check (change_request_type in ('cancel','reschedule')),
  requested_date date,
  requested_shift smallint check (requested_shift between 1 and 3),
  change_request_status text check (change_request_status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.dialysis_sessions (
  session_id uuid primary key default gen_random_uuid(),
  appointment_id uuid not null unique references public.appointments(appointment_id) on delete cascade,
  machine_id uuid references public.dialysis_machines(machine_id),
  staff_id uuid references public.users(user_id) on delete set null,
  session_date date not null,
  session_status text not null default 'scheduled'
    check (session_status in ('scheduled','completed','missed','cancelled')),
  treatment_details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  audit_id uuid primary key default gen_random_uuid(),
  staff_id uuid references public.users(user_id) on delete set null,
  operating_day smallint,
  shift_number smallint,
  opening_time time,
  activity_date date not null default current_date,
  activity_time time not null default localtime,
  activity text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);


-- Supporting records used by the original interface (announcements and notifications).
-- They supplement, but do not replace, the core ERD entities above.
create table if not exists public.announcements (
  announcement_id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  image_path text,
  posted_by uuid references public.users(user_id) on delete set null,
  created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  notification_id uuid primary key default gen_random_uuid(),
  recipient_user_id uuid references public.users(user_id) on delete cascade,
  recipient_role text check (recipient_role in ('staff','admin')),
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now(),
  check ((recipient_user_id is not null) <> (recipient_role is not null))
);

create index if not exists idx_patients_user on public.patients(user_id);
create index if not exists idx_appointments_patient on public.appointments(patient_id);
create index if not exists idx_appointments_status on public.appointments(appointment_status);
create index if not exists idx_slots_date_schedule on public.appointment_slots(appointment_date,schedule_id);
create index if not exists idx_sessions_date_status on public.dialysis_sessions(session_date,session_status);
create index if not exists idx_audit_created on public.audit_logs(created_at desc);
create index if not exists idx_notifications_user on public.notifications(recipient_user_id,created_at desc);
create index if not exists idx_notifications_role on public.notifications(recipient_role,created_at desc);

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant select on public.announcements to anon;

-- Create a patient account/profile automatically when a patient signs up.
create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.users(user_id,name,email,role)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)), new.email, 'patient')
  on conflict (user_id) do update set email=excluded.email;
  if coalesce(new.raw_user_meta_data->>'account_type','patient')='patient' then
    insert into public.patients(user_id,gender,date_of_birth,civil_status,address,contact_number,emergency_contact_name,emergency_contact_number)
    values (new.id,new.raw_user_meta_data->>'gender',nullif(new.raw_user_meta_data->>'date_of_birth','')::date,new.raw_user_meta_data->>'civil_status',new.raw_user_meta_data->>'address',new.raw_user_meta_data->>'contact_number',new.raw_user_meta_data->>'emergency_contact_name',new.raw_user_meta_data->>'emergency_contact_number')
    on conflict (user_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_reliance on auth.users;
create trigger on_auth_user_created_reliance
after insert on auth.users for each row execute procedure public.handle_new_auth_user();

create or replace function public.current_app_role()
returns text language sql stable security definer set search_path=public
as $$ select role from public.users where user_id=auth.uid() and is_active=true limit 1 $$;

create or replace function public.is_staff_or_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_app_role() in ('staff','admin'),false) $$;

-- Patient requests reserve one of the ten available machine slots atomically.
create or replace function public.request_appointment(p_date date, p_shift_number smallint)
returns uuid language plpgsql security definer set search_path=public
as $$
declare
  v_patient uuid;
  v_schedule uuid;
  v_slot uuid;
  v_day smallint;
  v_appointment uuid;
begin
  if auth.uid() is null then raise exception 'Please log in first.'; end if;
  if public.current_app_role() <> 'patient' then raise exception 'Only patient accounts can request appointments.'; end if;
  if p_date <= current_date then raise exception 'Choose a future appointment date.'; end if;
  if exists(select 1 from public.holidays where holiday_date=p_date) then raise exception 'The center is closed on this date (holiday). Please choose another date.'; end if;
  if p_shift_number not between 1 and 3 then raise exception 'Invalid shift.'; end if;
  v_day := extract(dow from p_date)::smallint;
  select patient_id into v_patient from public.patients where user_id=auth.uid();
  if v_patient is null then raise exception 'Patient profile not found.'; end if;
  if exists(select 1 from public.patients where patient_id=v_patient and verification_status='incomplete') then
    raise exception 'Your submitted requirements need correction before booking. Check Medical Records.';
  end if;
  select schedule_id into v_schedule from public.schedules
    where operating_day=v_day and shift_number=p_shift_number and status='active';
  if v_schedule is null then raise exception 'This schedule is not available.'; end if;
  if exists (
    select 1 from public.appointments a join public.appointment_slots s on s.slot_id=a.slot_id
    where a.patient_id=v_patient and s.appointment_date=p_date
      and (select shift_number from public.schedules where schedule_id=s.schedule_id)=p_shift_number
      and a.appointment_status in ('pending','confirmed')
  ) then raise exception 'You already have an active appointment for this shift.'; end if;
  insert into public.appointment_slots(schedule_id,appointment_date,machine_id,available_capacity)
  select v_schedule,p_date,m.machine_id,1 from public.dialysis_machines m
  where m.machine_status='active' and m.availability_status='available'
  on conflict(schedule_id,appointment_date,machine_id) do nothing;
  select s.slot_id into v_slot
  from public.appointment_slots s
  join public.dialysis_machines m on m.machine_id=s.machine_id
  where s.schedule_id=v_schedule and s.appointment_date=p_date
    and m.machine_status='active' and m.availability_status='available'
    and not exists(select 1 from public.appointments a where a.slot_id=s.slot_id
      and a.appointment_status in ('pending','confirmed'))
  order by m.machine_number
  limit 1 for update of s skip locked;
  if v_slot is null then raise exception 'This shift is fully booked.'; end if;
  insert into public.appointments(patient_id,slot_id,appointment_status)
    values(v_patient,v_slot,'pending') returning appointment_id into v_appointment;
  return v_appointment;
end;
$$;

-- Audit helper: callers can only write an entry under their own authenticated account.
create or replace function public.write_audit(p_activity text,p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required.'; end if;
  insert into public.audit_logs(staff_id,activity,details)
  values(auth.uid(),left(p_activity,500),coalesce(p_details,'{}'::jsonb));
end;
$$;


create or replace function public.approve_appointment(p_appointment_id uuid,p_machine_number integer default null)
returns void language plpgsql security definer set search_path=public
as $$
declare v_a public.appointments%rowtype; v_slot public.appointment_slots%rowtype; v_target uuid;
begin
  if not public.is_staff_or_admin() then raise exception 'Staff access required.'; end if;
  select * into v_a from public.appointments where appointment_id=p_appointment_id for update;
  if not found or v_a.appointment_status<>'pending' then raise exception 'This request is no longer pending.'; end if;
  if exists(select 1 from public.patients where patient_id=v_a.patient_id and verification_status<>'verified') then raise exception 'Verify the patient requirements before confirming the first appointment.'; end if;
  select * into v_slot from public.appointment_slots where slot_id=v_a.slot_id;
  select s.slot_id into v_target from public.appointment_slots s
  join public.dialysis_machines m on m.machine_id=s.machine_id
  where s.schedule_id=v_slot.schedule_id and s.appointment_date=v_slot.appointment_date
    and m.machine_status='active' and m.availability_status='available'
    and (p_machine_number is null or m.machine_number=p_machine_number)
    and not exists(select 1 from public.appointments a where a.slot_id=s.slot_id
      and a.appointment_id<>p_appointment_id and a.appointment_status in ('pending','confirmed'))
  order by case when p_machine_number is null then m.machine_number else 0 end
  limit 1 for update of s skip locked;
  if v_target is null then raise exception 'The selected machine or shift is no longer available.'; end if;
  update public.appointments set slot_id=v_target,appointment_status='confirmed',updated_at=now()
    where appointment_id=p_appointment_id;
  insert into public.dialysis_sessions(appointment_id,machine_id,staff_id,session_date,session_status)
  select p_appointment_id,s.machine_id,auth.uid(),s.appointment_date,'scheduled'
  from public.appointment_slots s where s.slot_id=v_target
  on conflict(appointment_id) do update set machine_id=excluded.machine_id,staff_id=excluded.staff_id,session_date=excluded.session_date,session_status='scheduled';
end;
$$;

create or replace function public.process_appointment_change_request(p_appointment_id uuid,p_approve boolean)
returns void language plpgsql security definer set search_path=public
as $$
declare v_a public.appointments%rowtype; v_old public.appointment_slots%rowtype; v_sched uuid; v_target uuid;
begin
  if not public.is_staff_or_admin() then raise exception 'Staff access required.'; end if;
  select * into v_a from public.appointments where appointment_id=p_appointment_id for update;
  if not found or v_a.change_request_status<>'pending' then raise exception 'No pending change request found.'; end if;
  if not p_approve then
    update public.appointments set change_request_status='rejected',change_request_type=null,requested_date=null,requested_shift=null,updated_at=now() where appointment_id=p_appointment_id;
    return;
  end if;
  if v_a.change_request_type='cancel' then
    update public.appointments set appointment_status='cancelled',change_request_status='approved',change_request_type=null,requested_date=null,requested_shift=null,updated_at=now() where appointment_id=p_appointment_id;
    update public.dialysis_sessions set session_status='cancelled' where appointment_id=p_appointment_id;
    return;
  end if;
  if v_a.change_request_type='reschedule' then
    select * into v_old from public.appointment_slots where slot_id=v_a.slot_id;
    select schedule_id into v_sched from public.schedules where operating_day=extract(dow from v_a.requested_date)::smallint and shift_number=v_a.requested_shift and status='active';
    if v_sched is null then raise exception 'Requested schedule is unavailable.'; end if;
    if exists(select 1 from public.appointments a join public.appointment_slots s on s.slot_id=a.slot_id where a.patient_id=v_a.patient_id and a.appointment_id<>p_appointment_id and s.appointment_date=v_a.requested_date and s.schedule_id=v_sched and a.appointment_status in ('pending','confirmed')) then raise exception 'The patient already has an appointment for that shift.'; end if;
    insert into public.appointment_slots(schedule_id,appointment_date,machine_id,available_capacity)
      select v_sched,v_a.requested_date,m.machine_id,1 from public.dialysis_machines m where m.machine_status='active' and m.availability_status='available'
      on conflict(schedule_id,appointment_date,machine_id) do nothing;
    select s.slot_id into v_target from public.appointment_slots s join public.dialysis_machines m on m.machine_id=s.machine_id
      where s.schedule_id=v_sched and s.appointment_date=v_a.requested_date and m.machine_status='active' and m.availability_status='available'
      and not exists(select 1 from public.appointments a where a.slot_id=s.slot_id and a.appointment_id<>p_appointment_id and a.appointment_status in ('pending','confirmed'))
      order by m.machine_number limit 1 for update of s skip locked;
    if v_target is null then raise exception 'The requested shift is full.'; end if;
    update public.appointments set slot_id=v_target,change_request_status='approved',change_request_type=null,requested_date=null,requested_shift=null,updated_at=now() where appointment_id=p_appointment_id;
    update public.dialysis_sessions ds set machine_id=(select machine_id from public.appointment_slots where slot_id=v_target),session_date=(select appointment_date from public.appointment_slots where slot_id=v_target) where ds.appointment_id=p_appointment_id;
  end if;
end;
$$;


create or replace function public.request_appointment_change(p_appointment_id uuid,p_change_type text,p_new_date date default null,p_new_shift smallint default null)
returns void language plpgsql security definer set search_path=public
as $$
declare v_patient uuid; v_status text;
begin
  if auth.uid() is null or public.current_app_role()<>'patient' then raise exception 'Patient access required.'; end if;
  select patient_id,appointment_status into v_patient,v_status from public.appointments where appointment_id=p_appointment_id;
  if v_patient is null or not exists(select 1 from public.patients where patient_id=v_patient and user_id=auth.uid()) then raise exception 'Appointment not found.'; end if;
  if v_status<>'confirmed' then raise exception 'Only confirmed appointments require staff review for changes.'; end if;
  if p_change_type not in ('cancel','reschedule') then raise exception 'Invalid change request.'; end if;
  if p_change_type='reschedule' and (p_new_date is null or p_new_date<=current_date or p_new_shift not between 1 and 3) then raise exception 'Choose a valid future date and shift.'; end if;
  if p_change_type='reschedule' and exists(select 1 from public.holidays where holiday_date=p_new_date) then raise exception 'The center is closed on this date (holiday). Please choose another date.'; end if;
  update public.appointments set change_request_type=p_change_type,requested_date=p_new_date,requested_shift=p_new_shift,change_request_status='pending',updated_at=now() where appointment_id=p_appointment_id;
end;
$$;

create or replace function public.reschedule_pending_appointment(p_appointment_id uuid,p_new_date date,p_new_shift smallint)
returns void language plpgsql security definer set search_path=public
as $$
declare v_patient uuid; v_sched uuid; v_slot uuid;
begin
  if auth.uid() is null or public.current_app_role()<>'patient' then raise exception 'Patient access required.'; end if;
  select patient_id into v_patient from public.appointments where appointment_id=p_appointment_id and appointment_status='pending' for update;
  if v_patient is null or not exists(select 1 from public.patients where patient_id=v_patient and user_id=auth.uid()) then raise exception 'Pending appointment not found.'; end if;
  if p_new_date<=current_date or p_new_shift not between 1 and 3 then raise exception 'Choose a valid future date and shift.'; end if;
  if exists(select 1 from public.holidays where holiday_date=p_new_date) then raise exception 'The center is closed on this date (holiday). Please choose another date.'; end if;
  select schedule_id into v_sched from public.schedules where operating_day=extract(dow from p_new_date)::smallint and shift_number=p_new_shift and status='active';
  if v_sched is null then raise exception 'This schedule is unavailable.'; end if;
  if exists(select 1 from public.appointments a join public.appointment_slots s on s.slot_id=a.slot_id where a.patient_id=v_patient and a.appointment_id<>p_appointment_id and s.appointment_date=p_new_date and s.schedule_id=v_sched and a.appointment_status in ('pending','confirmed')) then raise exception 'You already have an appointment for that shift.'; end if;
  insert into public.appointment_slots(schedule_id,appointment_date,machine_id,available_capacity)
    select v_sched,p_new_date,m.machine_id,1 from public.dialysis_machines m where m.machine_status='active' and m.availability_status='available'
    on conflict(schedule_id,appointment_date,machine_id) do nothing;
  select s.slot_id into v_slot from public.appointment_slots s join public.dialysis_machines m on m.machine_id=s.machine_id
    where s.schedule_id=v_sched and s.appointment_date=p_new_date and m.machine_status='active' and m.availability_status='available'
    and not exists(select 1 from public.appointments a where a.slot_id=s.slot_id and a.appointment_id<>p_appointment_id and a.appointment_status in ('pending','confirmed'))
    order by m.machine_number limit 1 for update of s skip locked;
  if v_slot is null then raise exception 'This shift is fully booked.'; end if;
  update public.appointments set slot_id=v_slot,updated_at=now() where appointment_id=p_appointment_id;
end;
$$;

create or replace function public.cancel_pending_appointment(p_appointment_id uuid)
returns void language plpgsql security definer set search_path=public
as $$
declare v_patient uuid;
begin
  if auth.uid() is null or public.current_app_role()<>'patient' then raise exception 'Patient access required.'; end if;
  select patient_id into v_patient from public.appointments where appointment_id=p_appointment_id and appointment_status='pending' for update;
  if v_patient is null or not exists(select 1 from public.patients where patient_id=v_patient and user_id=auth.uid()) then raise exception 'Pending appointment not found.'; end if;
  update public.appointments set appointment_status='cancelled',updated_at=now() where appointment_id=p_appointment_id;
end;
$$;


create or replace function public.create_notification(p_target_user_id uuid,p_target_role text,p_message text)
returns void language plpgsql security definer set search_path=public
as $$
declare v_role text;
begin
  v_role:=public.current_app_role();
  if auth.uid() is null or v_role is null then raise exception 'Authentication required.'; end if;
  if p_target_user_id is null and p_target_role not in ('staff','admin') then raise exception 'Invalid notification recipient.'; end if;
  if v_role='patient' and not ((p_target_role in ('staff','admin') and p_target_user_id is null) or p_target_user_id=auth.uid()) then raise exception 'Patients may only notify themselves, staff, or the administrator.'; end if;
  if p_target_user_id is not null and v_role not in ('staff','admin') then raise exception 'Only staff can notify another account.'; end if;
  insert into public.notifications(recipient_user_id,recipient_role,message)
  values(p_target_user_id,p_target_role,left(p_message,2000));
end;
$$;

create or replace function public.mark_notifications_read()
returns void language plpgsql security definer set search_path=public
as $$
begin
  update public.notifications set is_read=true
  where recipient_user_id=auth.uid() or recipient_role=public.current_app_role();
end;
$$;

grant execute on function public.request_appointment(date,smallint) to authenticated;
grant execute on function public.write_audit(text,jsonb) to authenticated;
grant execute on function public.approve_appointment(uuid,integer) to authenticated;
grant execute on function public.process_appointment_change_request(uuid,boolean) to authenticated;
grant execute on function public.request_appointment_change(uuid,text,date,smallint) to authenticated;
grant execute on function public.reschedule_pending_appointment(uuid,date,smallint) to authenticated;
grant execute on function public.cancel_pending_appointment(uuid) to authenticated;
grant execute on function public.create_notification(uuid,text,text) to authenticated;
grant execute on function public.mark_notifications_read() to authenticated;
grant execute on function public.current_app_role() to authenticated;
grant execute on function public.is_staff_or_admin() to authenticated;


-- Prevent patient accounts from self-approving their profile or document submissions.
create or replace function public.guard_patient_owned_fields()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if auth.role()='authenticated' and public.current_app_role()='patient' then
    new.verification_status := case when new.verification_status in ('pending','incomplete') then new.verification_status else old.verification_status end;
    new.user_id := old.user_id;
    new.patient_id := old.patient_id;
  end if;
  return new;
end;
$$;
drop trigger if exists patients_guard_owned_fields on public.patients;
create trigger patients_guard_owned_fields before update on public.patients
for each row execute procedure public.guard_patient_owned_fields();

create or replace function public.guard_patient_medical_fields()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v jsonb;
begin
  if auth.role()='authenticated' and public.current_app_role()='patient' then
    if tg_op='UPDATE' then new.administrative_notes := old.administrative_notes; end if;
    -- Patient submissions can be pending staff review or automatically rejected only.
    for v in select * from jsonb_array_elements(coalesce(new.document_manifest,'[]'::jsonb)) loop
      if coalesce(v->>'status','') not in ('pending_staff_approval','automatically_rejected') then
        if tg_op <> 'UPDATE' then
          raise exception 'Patients cannot approve or staff-reject submitted documents.';
        elsif not exists (
          select 1 from jsonb_array_elements(coalesce(old.document_manifest,'[]'::jsonb)) old_doc
          where old_doc->>'path'=v->>'path' and old_doc->>'status'=v->>'status'
        ) then
          raise exception 'Patients cannot approve or staff-reject submitted documents.';
        end if;
      end if;
    end loop;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists medical_records_guard_fields on public.medical_records;
create trigger medical_records_guard_fields before insert or update on public.medical_records
for each row execute procedure public.guard_patient_medical_fields();

alter table public.users enable row level security;
alter table public.patients enable row level security;
alter table public.medical_records enable row level security;
alter table public.dialysis_machines enable row level security;
alter table public.schedules enable row level security;
alter table public.appointment_slots enable row level security;
alter table public.appointments enable row level security;
alter table public.dialysis_sessions enable row level security;
alter table public.audit_logs enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;

drop policy if exists users_read_self_or_staff on public.users;
create policy users_read_self_or_staff on public.users for select to authenticated
using (user_id=auth.uid() or public.is_staff_or_admin());
drop policy if exists users_admin_update on public.users;
create policy users_admin_update on public.users for update to authenticated
using (public.current_app_role()='admin') with check (public.current_app_role()='admin');
create or replace function public.guard_user_role_fields()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if auth.role()='authenticated' and public.current_app_role()<>'admin' then
    new.role := old.role;
    new.is_active := old.is_active;
    new.email := old.email;
  end if;
  return new;
end;
$$;
drop trigger if exists users_guard_role_fields on public.users;
create trigger users_guard_role_fields before update on public.users
for each row execute procedure public.guard_user_role_fields();
drop policy if exists users_staff_update_profile on public.users;
create policy users_staff_update_profile on public.users for update to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists patients_read_own_or_staff on public.patients;
create policy patients_read_own_or_staff on public.patients for select to authenticated
using (user_id=auth.uid() or public.is_staff_or_admin());
drop policy if exists patients_update_own_or_staff on public.patients;
create policy patients_update_own_or_staff on public.patients for update to authenticated
using (user_id=auth.uid() or public.is_staff_or_admin())
with check (user_id=auth.uid() or public.is_staff_or_admin());

drop policy if exists medical_read_own_or_staff on public.medical_records;
create policy medical_read_own_or_staff on public.medical_records for select to authenticated
using (exists(select 1 from public.patients p where p.patient_id=medical_records.patient_id and p.user_id=auth.uid()) or public.is_staff_or_admin());
drop policy if exists medical_insert_own_or_staff on public.medical_records;
create policy medical_insert_own_or_staff on public.medical_records for insert to authenticated
with check (exists(select 1 from public.patients p where p.patient_id=medical_records.patient_id and p.user_id=auth.uid()) or public.is_staff_or_admin());
drop policy if exists medical_update_own_or_staff on public.medical_records;
create policy medical_update_own_or_staff on public.medical_records for update to authenticated
using (exists(select 1 from public.patients p where p.patient_id=medical_records.patient_id and p.user_id=auth.uid()) or public.is_staff_or_admin())
with check (exists(select 1 from public.patients p where p.patient_id=medical_records.patient_id and p.user_id=auth.uid()) or public.is_staff_or_admin());

drop policy if exists machines_read on public.dialysis_machines;
create policy machines_read on public.dialysis_machines for select to authenticated using (true);
drop policy if exists machines_staff_manage on public.dialysis_machines;
create policy machines_staff_manage on public.dialysis_machines for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists schedules_read on public.schedules;
create policy schedules_read on public.schedules for select to authenticated using (true);
drop policy if exists schedules_staff_manage on public.schedules;
create policy schedules_staff_manage on public.schedules for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists slots_read on public.appointment_slots;
create policy slots_read on public.appointment_slots for select to authenticated using (true);
drop policy if exists slots_staff_manage on public.appointment_slots;
create policy slots_staff_manage on public.appointment_slots for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists appointments_read_own_or_staff on public.appointments;
create policy appointments_read_own_or_staff on public.appointments for select to authenticated
using (exists(select 1 from public.patients p where p.patient_id=appointments.patient_id and p.user_id=auth.uid()) or public.is_staff_or_admin());
drop policy if exists appointments_staff_update on public.appointments;
create policy appointments_staff_update on public.appointments for update to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists sessions_read_own_or_staff on public.dialysis_sessions;
create policy sessions_read_own_or_staff on public.dialysis_sessions for select to authenticated
using (exists(select 1 from public.appointments a join public.patients p on p.patient_id=a.patient_id where a.appointment_id=dialysis_sessions.appointment_id and p.user_id=auth.uid()) or public.is_staff_or_admin());
drop policy if exists sessions_staff_manage on public.dialysis_sessions;
create policy sessions_staff_manage on public.dialysis_sessions for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

drop policy if exists audit_admin_read on public.audit_logs;
create policy audit_admin_read on public.audit_logs for select to authenticated
using (public.current_app_role()='admin');

drop policy if exists announcements_public_read on public.announcements;
create policy announcements_public_read on public.announcements for select to anon,authenticated using (true);
drop policy if exists announcements_admin_manage on public.announcements;
create policy announcements_admin_manage on public.announcements for all to authenticated
using (public.current_app_role()='admin') with check (public.current_app_role()='admin');
drop policy if exists notifications_read_own on public.notifications;
create policy notifications_read_own on public.notifications for select to authenticated
using (recipient_user_id=auth.uid() or recipient_role=public.current_app_role());
drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications for update to authenticated
using (recipient_user_id=auth.uid() or recipient_role=public.current_app_role())
with check (recipient_user_id=auth.uid() or recipient_role=public.current_app_role());

-- Private bucket for patient medical documents. Files are stored as <patient_uuid>/<file>.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('medical-documents','medical-documents',false,5242880,array['application/pdf','image/jpeg','image/png'])
on conflict(id) do update set public=false,file_size_limit=5242880,allowed_mime_types=array['application/pdf','image/jpeg','image/png'];

drop policy if exists medical_docs_read on storage.objects;
create policy medical_docs_read on storage.objects for select to authenticated
using (bucket_id='medical-documents' and (
  public.is_staff_or_admin() or exists(
    select 1 from public.patients p where p.patient_id::text=(storage.foldername(name))[1] and p.user_id=auth.uid()
  )
));
drop policy if exists medical_docs_insert on storage.objects;
create policy medical_docs_insert on storage.objects for insert to authenticated
with check (bucket_id='medical-documents' and exists(
  select 1 from public.patients p where p.patient_id::text=(storage.foldername(name))[1] and p.user_id=auth.uid()
));
drop policy if exists medical_docs_delete on storage.objects;
create policy medical_docs_delete on storage.objects for delete to authenticated
using (bucket_id='medical-documents' and (public.is_staff_or_admin() or exists(
  select 1 from public.patients p where p.patient_id::text=(storage.foldername(name))[1] and p.user_id=auth.uid()
)));


insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('announcements','announcements',true,2097152,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=true,file_size_limit=2097152,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists announcement_images_public_read on storage.objects;
create policy announcement_images_public_read on storage.objects for select to anon,authenticated using (bucket_id='announcements');
drop policy if exists announcement_images_admin_insert on storage.objects;
create policy announcement_images_admin_insert on storage.objects for insert to authenticated
with check (bucket_id='announcements' and public.current_app_role()='admin');
drop policy if exists announcement_images_admin_delete on storage.objects;
create policy announcement_images_admin_delete on storage.objects for delete to authenticated
using (bucket_id='announcements' and public.current_app_role()='admin');

-- Provision ten machines but operate one, for three patient appointments per open day.
insert into public.dialysis_machines(machine_number) select n from generate_series(1,10) n
on conflict(machine_number) do nothing;
update public.dialysis_machines
set machine_status=case when machine_number=1 then 'active' else 'inactive' end
where machine_number<>1;
insert into public.schedules(operating_day,shift_number,opening_time,closing_time,status)
select d,s,case s when 1 then time '08:00' when 2 then time '11:00' else time '14:00' end,
       case s when 1 then time '11:00' when 2 then time '14:00' else time '17:00' end,'active'
from generate_series(1,6) d cross join generate_series(1,3) s
on conflict(operating_day,shift_number) do nothing;

-- Holidays: the center is closed and patients cannot book these dates.
create table if not exists public.holidays (
  holiday_date date primary key,
  name text not null
);
alter table public.holidays enable row level security;
drop policy if exists holidays_read on public.holidays;
create policy holidays_read on public.holidays for select to authenticated using (true);
drop policy if exists holidays_admin_write on public.holidays;
create policy holidays_admin_write on public.holidays for all to authenticated
using (public.current_app_role()='admin') with check (public.current_app_role()='admin');
insert into public.holidays(holiday_date,name) values
('2026-01-01','New Year''s Day'),('2026-02-17','Chinese New Year'),('2026-04-02','Maundy Thursday'),('2026-04-03','Good Friday'),
('2026-04-04','Black Saturday'),('2026-04-09','Araw ng Kagitingan'),('2026-05-01','Labor Day'),('2026-06-12','Independence Day'),
('2026-08-21','Ninoy Aquino Day'),('2026-08-31','National Heroes Day'),('2026-11-01','All Saints'' Day'),('2026-11-02','All Souls'' Day'),
('2026-11-30','Bonifacio Day'),('2026-12-08','Feast of the Immaculate Conception'),('2026-12-24','Christmas Eve'),('2026-12-25','Christmas Day'),
('2026-12-30','Rizal Day'),('2026-12-31','Last Day of the Year'),('2027-01-01','New Year''s Day')
on conflict(holiday_date) do nothing;

-- If your database already exists, update the session times too:
-- update public.schedules set opening_time=case shift_number when 1 then time '08:00' when 2 then time '11:00' else time '14:00' end,
--   closing_time=case shift_number when 1 then time '11:00' when 2 then time '14:00' else time '17:00' end;
