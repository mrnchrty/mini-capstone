import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: corsHeaders });

  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (!token) throw new Error('Authentication required.');

    const callerClient = createClient(url, anonKey, { global: { headers: { Authorization: `Bearer ${token}` } } });
    const { data: { user }, error: authError } = await callerClient.auth.getUser(token);
    if (authError || !user) throw new Error('Invalid session.');
    const { data: caller, error: roleError } = await callerClient.from('users').select('role,is_active').eq('user_id', user.id).single();
    if (roleError || caller?.role !== 'admin' || !caller.is_active) throw new Error('Administrator access required.');

    const { name, email, password } = await req.json();
    if (!name?.trim() || !email?.trim() || typeof password !== 'string' || password.length < 8) {
      throw new Error('Provide a name, valid email, and password of at least 8 characters.');
    }

    const adminClient = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const { data, error } = await adminClient.auth.admin.createUser({
      email: email.trim().toLowerCase(),
      password,
      email_confirm: true,
      user_metadata: { name: name.trim(), account_type: 'staff' },
    });
    if (error) throw error;
    const { error: updateError } = await adminClient.from('users').update({ name: name.trim(), role: 'staff', is_active: true }).eq('user_id', data.user.id);
    if (updateError) throw updateError;

    return new Response(JSON.stringify({ user_id: data.user.id, email: data.user.email, role: 'staff' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200,
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Request failed.' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400,
    });
  }
});
