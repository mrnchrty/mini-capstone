/* Add the Project URL and publishable/anon key from Supabase Settings > API.
   Never put a service_role or secret key in this browser file. */
window.RDC_SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
window.RDC_SUPABASE_ANON_KEY = 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY';
