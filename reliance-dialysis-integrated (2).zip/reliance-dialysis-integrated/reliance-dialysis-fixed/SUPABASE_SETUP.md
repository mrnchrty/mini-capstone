# Supabase setup — Reliance Dialysis Center Inc.

## 1. Create the project

1. Go to https://supabase.com and sign in or create an account.
2. Select **New project**.
3. Choose an organization.
4. Set the project name to `reliance-dialysis-center`.
5. Create a strong database password and store it somewhere safe. Do not put it in the website source.
6. Choose a region close to the Philippines if available (for example, Singapore).
7. Create the project and wait until provisioning finishes.

## 2. Create the database structure

1. Open the project dashboard.
2. Select **SQL Editor**.
3. Choose **New query**.
4. Open `supabase/schema.sql` from this project and copy its entire contents.
5. Paste the SQL into the SQL Editor and click **Run**.
6. Confirm that the tables appear under **Table Editor**: users, patients, medical_records, schedules, appointment_slots, appointments, dialysis_sessions, dialysis_machines, audit_logs, announcements, and notifications.
7. Confirm that the `medical-documents` and `announcements` Storage buckets exist.

If the SQL Editor reports an error, stop and send the exact error message. Do not run only random portions of the script; the functions and policies depend on the tables created earlier in the file.

The schedule uses one active dialysis machine and three shifts, allowing up to three appointments per open day. For an existing project, run this capacity update in the SQL Editor so database booking limits match the app:

```sql
update public.dialysis_machines
set machine_status = case when machine_number = 1 then 'active' else 'inactive' end
where machine_number <> 1;
```

## 3. Configure Authentication

1. Open **Authentication → URL Configuration**.
2. Set the Site URL to `http://localhost:5500` while testing locally.
3. Add these Redirect URLs:
   - `http://localhost:5500/**`
   - `http://127.0.0.1:5500/**`
4. Open **Authentication → Providers → Email**.
5. Keep email/password authentication enabled.
6. For initial local testing, you may temporarily disable email confirmation so test accounts can sign in immediately. Re-enable confirmation before any real deployment.

## 4. Create the first administrator account

1. Run the local app as described in `README.md`.
2. Register an account using the actual administrator's designated email address.
3. If email confirmation is enabled, confirm the email first.
4. Return to **SQL Editor** and run this query, replacing the email with the exact account you just registered:

```sql
update public.users
set role = 'admin'
where email = 'your-admin-email@example.com';

delete from public.patients
where user_id = (
  select user_id from public.users
  where email = 'your-admin-email@example.com'
);
```

5. Sign out of the app and sign in again. The account should open the administrator analytics dashboard.

Do not promote a public test account to administrator on a live project.

## 5. Add the browser connection keys

1. Open **Project Settings → API** (the exact menu label may appear as **API Keys** in some dashboard versions).
2. Copy the Project URL.
3. Copy the publishable key (or legacy anon/public key).
4. Open `supabase-config.js` in the project folder and replace the placeholders:

```js
window.RDC_SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
window.RDC_SUPABASE_ANON_KEY = 'YOUR_PUBLISHABLE_OR_ANON_KEY';
```

The publishable/anon key is intended for browser use when Row Level Security is correctly enabled. **Never use the service_role key or a secret key in this file.**

## 6. Deploy the staff-account Edge Function

The administrator creates staff accounts from **Users and roles**. This action must run on a trusted server function because creating Auth users requires the service-role key.

Install the Supabase CLI, sign in, link the project, and deploy:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy admin-create-user
```

The function uses the Supabase-provided `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` environment variables. Do not copy the service-role key into the frontend.

## 7. Start and test

Start the local server:

```bash
py -m http.server 5500
```

Open `http://localhost:5500`.

Suggested test sequence:

1. Register a patient account and confirm the email if required.
2. Sign in as the patient and complete the profile.
3. Try submitting without required documents; it should show an automatic rejection and not become eligible for staff approval.
4. Submit valid sample files (PDF/JPG/PNG, within the size limit, three treatment sheets, recent lab date). The patient status should become pending staff approval.
5. Sign in as staff (created by the administrator) and open Patient Records. Verify the documents and mark the profile verified.
6. Sign in as the patient and request a future date/shift.
7. Sign in as staff, approve the appointment, and verify a machine is assigned.
8. Mark a session completed or missed on/after its date. Confirm that the patient appointment history and admin analytics update.
9. Sign in as administrator. Check analytics, role management, announcements, and audit log.
10. Refresh the browser and sign in again. Confirm that records remain in PostgreSQL.

## 8. Security checklist before using real records

- Re-enable email confirmation.
- Review every RLS policy and test with patient, staff, and admin accounts separately.
- Keep the medical document bucket private.
- Use HTTPS for deployment and configure the correct production Site URL/redirect URLs.
- Restrict access to the Supabase project dashboard and service-role secret.
- Do not use real patient records for development tests.
- Have the center's authorized personnel review privacy notices, consent, retention, backups, and access procedures before production use.
